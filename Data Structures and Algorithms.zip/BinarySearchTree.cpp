
#include <iostream>
#include <fstream>
#include <sstream>

#include "BinarySearchTree.h"


using namespace std;

namespace bst {

	// Default constructor
	Node::Node() {

		left = nullptr;
		right = nullptr;
	};
	// initialize node with a course
	Node::Node(Course aCourse) : Node() {
		course = aCourse;
	};

	// default constructor
	Course::Course() {
		courseId = "";
		courseName = "";

	};

	//============================================================================
	// Binary Search Tree class implementation
	//============================================================================

	// initialize root
	BinarySearchTree::BinarySearchTree() {
		root = nullptr;
	}

	/**
	 * Destructor
	*/
	BinarySearchTree::~BinarySearchTree() {

		if (root != nullptr) {
			deleteTree(root);
		}

	}

	/**
	 * Recursive function to delete a subtree
	 */
	void BinarySearchTree::deleteTree(Node* node)
	{
		if (node == nullptr) {
			return;
		}

		deleteTree(node->left);		// Transverse left subtree
		deleteTree(node->right);	// Transverse right subtree

		delete node;	// free memory
	}


	/**
	* Create a course
	*/
	void BinarySearchTree::CreateCourse(string fileInput) {

		istringstream iss(fileInput);
		vector<string> tokens;
		string token;
		
		// stplit string into tokens
		while (std::getline(iss, token, ',')) {
			tokens.push_back(token);
		}

		// create course instance
		Course course;
		course.courseId = tokens.at(0);
		course.courseName = tokens.at(1);

		// if course has prerequisites
		if (tokens.size() > 2) {
			for (int i = 2; i < tokens.size(); ++i) {
				course.prerequisites.push_back(tokens.at(i));
			}
		}
		// inserts course into data structure
		InsertCourse(course);
	}

	/**
	 * Insert a course
	 */
	void BinarySearchTree::InsertCourse(Course course) {

		Node* newNode = new Node(course);	// create new node instance

		if (root == nullptr) {
			root = newNode;
			newNode->left = nullptr;
			newNode->right = nullptr;
		}
		else {
			// add Node root add node root and bid
			addNode(root, course);
		}
	}

/**
 * Add a course to some node (recursive)
 * @param node Current node in tree
 * @param course Course to be added
 */
	void BinarySearchTree::addNode(Node* node, Course course) {

		Node* newNode = new Node(course);

		if (course.courseId < node->course.courseId) {
			if (node->left == nullptr) {        // add to left
				node->left = newNode;
			}
			else {      // recurse down left node
				addNode(node->left, course);
			}
		}
		else {
			if (node->right == nullptr) {       // add to right
				node->right = newNode;
			}
			else {      // recurse down right node
				addNode(node->right, course);
			}
		}
	}

	/**
	* Search for a course
	*/
	Course BinarySearchTree::Search(string courseId) {

		Course course;

		Node* currNode = root;

		while (currNode != nullptr) {       // iterate over the tree
			if (currNode->course.courseId == courseId) {    // matching bidId found
				return currNode->course;
			}
			else if (courseId < currNode->course.courseId) {     // iterates over left side
				currNode = currNode->left;
			}
			else {      // bidId > currNode: iterates over right side
				currNode = currNode->right;
			}
		}
		// course not found
		return course;
	}

	/**
	* print a course
	*/
	void BinarySearchTree::PrintCourse(string courseId) {
		
		Course course;
		course = Search(courseId);		// search course

		// course not found
		if (course.courseId.empty()) {
			cout << " Course not found..." << endl;
			return;
		}

		cout << "Course ID: " << course.courseId << endl;
		cout << "Course name: " << course.courseName << endl;
		if (!course.prerequisites.empty()) {
			cout << "Prerequisites:" << endl;
			for (string& prerequisite : course.prerequisites) {
				cout << "  -" << prerequisite << endl;
			}
		}
		cout << endl;
	}

	/**
	* Transverse tree in order
	*/
	void BinarySearchTree::inOrder(Node* node) {

		if (root == nullptr) {		// tree is empty
			cout << "No courses available..." << endl;
		}

		if (node == nullptr) {
			return;
		}

		if (node != nullptr) {
			inOrder(node->left);
			cout << " " << node->course.courseId << ", " << node->course.courseName << endl;
			inOrder(node->right);
		}
		
	}

	/**
	* print a course
	*/
	void BinarySearchTree::PrintAll() {
		inOrder(root);
	}

	//============================================================================
	// Static testing methods
	//============================================================================

	/**
	 * Print menu to console
	 */
	void Menu() {
		cout << "   1. Load Data Structure." << endl;
		cout << "   2. Print Course List." << endl;
		cout << "   3. Print Course." << endl;
		cout << "   9. Exit" << endl;
	}

	/**
	 * Reads and loads courses from a CSV & text file
	 */
	void LoadCources(BinarySearchTree* bst, string fileName) {

		ifstream tempsSF;
		string fileInput;
		string fileExtension;

		fileExtension = fileName.substr(fileName.size() - 3, 3);

		tempsSF.open(fileName);
		if (tempsSF.is_open()) {

			if (fileExtension == "csv") {		
				// get header
				getline(tempsSF, fileInput);
			}

			// Reads data from file and inserts it into variables.
			while (getline(tempsSF, fileInput)) {

				bst->CreateCourse(fileInput);

				if (tempsSF.fail()) {
					// Informs the user if an error has occured while reading the file.
					cout << "Error found while reading data..." << endl;
					break;
				}
			}
			// close the file.
			tempsSF.close();
		}
		else {
			// Informs the user if the file cannot be open
			cout << "Could not find " << fileName << " ...\n" << endl;
		}
	}
}