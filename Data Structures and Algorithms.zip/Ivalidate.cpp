#include <iostream>
#include <string>
#include "Ivalidate.h"


namespace ival {

	/*
	* Validates user input by discarting values that are of invalid data type.
	* @param t_prompt to prompt the user for input
	* @return user_integer valid user integer
	*/
	double doubleValidation(const string& t_prompt) {

		double user_integer;

		cout << t_prompt;
		cin >> user_integer;

		// loop repeats while the input is of an invalid data type, in this case integer.
		while (cin.fail()) {
			// clears error flags from cin.
			cin.clear();
			// Ignores anything from the line and jumps to the new line waiting for new input
			cin.ignore(std::numeric_limits<streamsize>::max(), '\n');
			cout << "Invalid input. Please try again." << endl;
			cin >> user_integer;
		}

		return user_integer;
	}

	/*
	* Validates user input and discarts values that are out of a specific range.
	* @param t_prompt to prompt the user for input
	* @param t_min lower boud integer
	* @param t_max higher bound integer
	* @return userInput valid user input
	*/
	double getDouble(const string& t_prompt, int t_min, int t_max) {

		double userInput;
		// Ensures that the entered input is of correct data type.
		userInput = doubleValidation(t_prompt);

		while (userInput < t_min || userInput > t_max) {
		//	cout << userInput << " is not an option";
			userInput = doubleValidation(t_prompt);
		}
		//cout << endl;
		return userInput;
	}

	/*
	* Converts a string to upper case
	* @param userInput string entereb by the user
	* @return newString new string converted to upper characters
	*/
	string toUpper(string userInput) {
		
		string newString;		// create new empty string

		for (auto c : userInput) {		// iterates over every character
			c = toupper(c);
			
			newString.push_back(c);		// inserts new upper character to new string
		}
		return newString;
	}

}

