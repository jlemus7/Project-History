package com.gamingroom;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

/**
 * A simple class to hold information about a team
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a team is
 * created.
 * </p>
 * @author coce@snhu.edu
 *
 */
public class Team {
	long id;
	String name;
	
	/**
	 * A list of the active players
	 */
	private static List<Player> players = new ArrayList<Player>();
	
	
	/*
	 * Constructor with an identifier and name
	 */
	public Team(long id, String name) {
		this.id = id;
		this.name = name;
	}
	
	
	public Player addPlayer(String name) {
		
		// local player instance
		Player player = null;
		
		Iterator<Player> playerIterator = players.iterator();
		
		/*
		 * The Iterator pattern iterates over the list of players without
		 * exposing the underlying structure of the list. It makes the
		 * code easy to understand and improves the modularity of the project.
		 */
		while(playerIterator.hasNext()) {
			
			// creates a local instance of the Iterator
			Player existingPlayer = playerIterator.next();
			
			/*
			 * Loops through the entire list of players, if the name already
			 * exists, returns existing instance of that player.
			 */
			if (existingPlayer.getName().equals(name)) {
				player = existingPlayer;
				break;
			}
			
			// creates a new instance of the player and adds it to the list, if not fund.
			if(player == null) {
				player = new Player(id++, name);
				players.add(player);
			}
		}
		
		// return the new/existing game instance to the caller
		return player;
	}

	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return "Team [id=" + id + ", name=" + name + "]";
	}
	
}
