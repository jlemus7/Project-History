package com.gamingroom;



/**
 * A simple class to hold information about an entity
 * <p>
 * This will be the base class for the Game, Team and
 * Player classes. Its methods will be overloaded by
 * the child classes to create the respective entity.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once an entity is
 * created.
 * </p>
 * @author jose.lemus1@snhu.edu
 */
public class Entity {
	
	/*
	 * Holds the object's identifier.
	 */
	private long id;
	
	/*
	 * Holds the object's name.
	 */
	private String name;
	
	/*
	 * Private constructor, ensures that only one instance of the class
	 * exists at any given point.
	 */
	private Entity() {
	
	}
	
	/*
	 * Public constructor utilized to initialize private variables
	 */
	public Entity(long id, String name ) {
		this.id = id;
		this.name = name;
	}
	
	/**
	 * @return the id
	 */
	public long getId() {
		return id;
		
	}
	
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * @return the object's id and name
	 */
	public String toString() {
		
		return "Entity [id=" + id + ", name=" + name + "]";
	}

}
