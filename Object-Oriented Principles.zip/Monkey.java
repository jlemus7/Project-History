public class Monkey extends RescueAnimal {
	
	private String tailLength;
	private String height;
	private String bodyLength;
	private String species;
	
	// constructor
	public Monkey(String name, String species, String gender, String age,String weight,
			String height, String bodyLength, String tailLength,String acquisitionDate, 
			String acquisitionCountry, String trainingStatus, boolean reserved, String inServiceCountry) {
		
		setName(name);
		setSpecies(species);
        setGender(gender);
        setAge(age);
        setWeight(weight);
        setHeight(height);
        setBodyLength(bodyLength);
        setTailLength(tailLength);
        setAcquisitionDate(acquisitionDate);
        setAcquisitionLocation(acquisitionCountry);
        setTrainingStatus(trainingStatus);
        setReserved(reserved);
        setInServiceCountry(inServiceCountry);
	}
	
	// mutators
	public void setTailLength(String tailLength) {
		this.tailLength = tailLength;
	}
	
	public void setHeight(String height) {
		this.height = height;
	}
	
	public void setBodyLength(String bodyLength) {
		this.bodyLength = bodyLength;
	}
	
	public void setSpecies(String species) {
		this.species = species;
	}
	
	// accessors
	public String getTailLength() {
		return tailLength;
	}
	
	public String getHeight() {
		return height;
	}
	
	public String getBodyLength() {
		return bodyLength;
	}
	
	public String getSpecies() {
		return species;
	}

}
