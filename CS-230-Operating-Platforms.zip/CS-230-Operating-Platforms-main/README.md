# Cplusplus-Program

1) Briefly summarize The Gaming Room client and their software requirements. Who was the client? What type of software did they want you to design?

The Gaming Room wants to develop a web-based application for their game Draw It or Lose It. This game must hold the same characteristics as their current mobile version, which is only available on Android.
Draw It or Lose It is a game that is loosely similar to the 1980s television show “Game Win, Lose or Draw,” where teams compete to guess what is being drawn. In this game, however, the application will render images from a large library of stock drawings as clues. A game consists of four rounds of play lasting one minute each. Drawings are rendered at a steady rate and are fully complete at the 30-second mark. If the team does not guess the puzzle before time expires, the remaining teams have an opportunity to offer one guess each to solve the puzzle with a 15-second time limit.
For this application, I was tasked to review the three traditional operating platforms (Linux, Mac, and Windows), as well as mobile platforms in order to determine which operating platform could host the application successfully.
The application had the following requirements:
  1.	A game can have one or multiple teams involved.
  2.	Each team will have multiple players assigned to it.
  3.	The game and team names must be unique.
  4.	The user should be allowed to check whether a name is in use when choosing a name.
  5.	Only one instance of the game can exist in memory at any given time.
  6.	Each game must contain a unique identifier.


2) What did you do particularly well in developing this documentation?

One section that I did particularly well when developing this document was the identification of the design constraints. This section was challenging and engaging at the same time because I needed to identify possible limitations to the successful development of the application, whether was the software or hardware. For this, I needed to understand the functionality of each operating platform, and its ability to fulfill the client’s requirements for the application. Another section that I did particularly well was the understanding of the domain model. This is an important part of the software development process because it helped me recognize if I understood the functionality of the game presented by the UML diagram. I learned the importance of creating clear instructions, so the development process is clear for the client and any developer working on the project.


3) What about the process of working through a design document did you find helpful when developing the code?

The part of the design document that I found most helpful when developing the code was the domain model and the UML diagram. These parts were helpful because they were the main guide to fulfilling the application’s requirements. The layout of the diagram was important to understand what each class needed and their relationship with each other. As mentioned earlier, the model design section helped in this process because it helped me determine if I understood the functionality before I started coding. This is important because it can help to avoid mistakes when writing the code.
If you could choose one part of your work on these documents to revise, what would you pick? How would you improve it?
The section that I would choose to revise would be the evaluation and recommendations section. Although I learned a lot in this class about operating systems, both advantages and disadvantages, I consider that this knowledge is not enough to determine the recommendations of this application. I consider that a deeper understanding of each operating system’s characteristics is needed in order to compromise a client on such recommendations.


4) How did you interpret the user’s needs and implement them into your software design? Why is it so important to consider the user’s needs when designing?

When developing an application, it is important to consider the user’s perspective because these individuals will be interacting with the application daily. It is important to keep the user experience in mind in order to increase engagement with the game.
In this software design, the user’s needs were met by proposing a design that will enhance security to protect the users’ data and privacy as well as operating systems and memory management solutions that can improve the application’s runtime on the user end. These are some of the most important features that can improve user engagement and therefore benefit the client.


5) How did you approach designing software? What techniques or strategies would you use in the future to analyze and design a similar software application?

The key aspect of a successful software design document is understanding the client’s requirements and the development limitations of both software and hardware. This was my approach to developing this design. First, it is important to understand what the client wants in the application. After the requirements have been labeled, it is important to analyze the software and hardware elements such as memory management, operating systems, databases, security, and storage to identify what requirements can be met and how. It is also important to identify potential roadblocks and constraints as well as provide a solution on how these can be eliminated. Lastly, it is important to provide recommendations for both software and hardware that can be implemented in the development of the application in order to be successful for both the user and the client.
