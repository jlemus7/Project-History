CS-360 Mobile Architect & Programming

Description:
This project is an application that has the purpose of managing the inventory of an individual. The app has the ability to display inventory items and allow users to add, update, and delete items from the list. Users can access this data by logging into their account. 
The app is intended to provide organization to the user by managing a list of items that the user wants to keep track of. This can be household items such as kitchen items, closet items, collections, etc. The current app is functional for single-user data but can be scalable for small businesses and even enterprises.

In order to support the users’ needs, the app provides a login screen where users can create an account and log into an existing account. Once logged in, the user has access to a home screen, an inventory screen, and an account screen.
The home screen provides basic information to the user such as item count and inventory total value. The home screen also contains an in-app notification section that displays messages to the user about low-stock items.
The inventory screen displays a list of all items held in the database by the user. The user has the ability to click on a specific item and review its details, here the user can choose to edit the item and update any of its fields.
The account screen has the ability to display user information such as name, ID, and email address. The user has the ability to update this information to keep an accurate record.
The app was developed with a user-centered approach and intuitive interface that provides easy navigation between screens. Users have access to almost all of the screens with one click of the taskbar or navigation bar.

The development process of this app required organization and planning in order to complete the app’s features. The app was developed using a modular approach completing feature by feature one screen at a time. This helped keep code blocks organized and helped the overall organization of the app and its classes. Having a plan from the beginning with tasks such as user stories or features will help improve the modularity and organization of the code. This can also reduce the amount of time I spend fixing errors at the end of the process.

Testing is one of the most important parts of the development process. During the development of this app, I continuously tested my code by running the app every time a new feature was added, or a change was made. This helped me maintain track of real progress by updating items and features from the to-do list once these were functionally integrated into the app.