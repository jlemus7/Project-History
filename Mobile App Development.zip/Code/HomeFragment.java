package com.zybooks.itemwise;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;
import android.widget.Toolbar;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private RecyclerView recyclerView;
    private List<Item> itemList;
    private List<Notification> notificationsList = new ArrayList<>();
    private NotificationAdapter notificationAdapter;
    private static final String PREFS_NAME = "MyPrefsFile";
    private final int DEFAULT_BOUND = 5;
    private Button countButton;
    private Button valueButton;

    private int inventoryTotal = 0;
    private double inventoryValue = 0.0;



    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_home, container, false);
        setHasOptionsMenu(true);    // recommended by android studio documentation

        populateList();

        recyclerView = rootView.findViewById(R.id.notifications);
        countButton = rootView.findViewById(R.id.count_button);
        valueButton = rootView.findViewById(R.id.value_button);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);

        notificationAdapter = new NotificationAdapter(notificationsList, getContext());
        recyclerView.setAdapter(notificationAdapter);

        calculateInventoryValue();

        onClicked(countButton, "Total item count", String.valueOf(inventoryTotal), "Close", "");
        onClicked(valueButton, "Total inventory value", "$" + String.valueOf(inventoryValue), "Close", "");

        return rootView;
    }

    // recommended by android studio documentation
    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater menuInflater) {

        menuInflater.inflate(R.menu.task_bar, menu);


        // presets visibility for icons
        menu.findItem(R.id.search).setVisible(false);
        menu.findItem(R.id.delete).setVisible(false);
        menu.findItem(R.id.edit).setVisible(false);
        menu.findItem(R.id.logout).setVisible(false);
        menu.findItem(R.id.check).setVisible(false);
        menu.findItem(R.id.close).setVisible(false);
        menu.findItem(R.id.back).setVisible(false);
        menu.findItem(R.id.settings).setVisible(true);
    }
@Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == R.id.settings) {

            FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

            SettingsFragment settingsFragment = new SettingsFragment();
            fragmentTransaction.replace(R.id.nav_host_fragment, settingsFragment, "SettingsFragment");
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }


    public void populateList() {

        notificationsList.clear();
        ItemsDatabase itemsDatabase = new ItemsDatabase(getContext());
        itemList = itemsDatabase.getAllItems();
        getNotifications();
    }

    public void getNotifications() {
        String title = "Low stock";
        int bound;
        SharedPreferences settings = requireContext().getSharedPreferences(PREFS_NAME, 0);
        boolean boundExists = settings.contains("lowBound");

        if (boundExists) {
            bound = settings.getInt("lowBound", 0);
        } else {
            bound = DEFAULT_BOUND;
        }

        for (Item item : itemList) {
            if (item.getQuantity() < bound) {
                Notification notification = new Notification(title, "You are running low on " + item.getName());
                notificationsList.add(notification);
            }
        }
    }

    public void onClicked(Button button, String title, String message, String positive, String negative) {
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AddEditDialog dialog = new AddEditDialog(title, message, positive, negative);
                dialog.setDialogListener(new DialogListener() {
                    @Override
                    public void onExitPositiveClick() {
                        // Return to inventory list
                    }
                    @Override
                    public void onExitNegativeClick() {
                        // Continue editing
                    }
                });
                dialog.show(getActivity().getSupportFragmentManager(), "DetailsDialog");
            }
        });
    }

    public void calculateInventoryValue() {

        int totalItems = 0;
        double totalValue = 0.0;

        for (Item item : itemList) {
            totalItems = totalItems + item.getQuantity();
            totalValue = totalValue + (item.getPrice() * item.getQuantity());
        }
        inventoryValue = totalValue;
        inventoryTotal = totalItems;
    }


}