package com.zybooks.itemwise;


import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.Currency;


public class AddItemFragment extends Fragment {

   private final String CURRENCY = "$";
    private EditText mItemName;
    private EditText mDescription;
    private EditText mItemNumber;
    private EditText mQuantity;
    private EditText mPrice;
    private EditText mLocation;
    private TextView mItemValue;

    private String itemName;
    private String itemDescription;
    private String itemNumber;
    private String itemQuantity;
    private String itemPrice;
    private String itemLocation;


    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View rootView = inflater.inflate(R.layout.fragment_add_item, container, false);

        setHasOptionsMenu(true);

        mItemName = rootView.findViewById(R.id.item_name_edit);
        mDescription= rootView.findViewById(R.id.item_description_edit);
        mItemNumber= rootView.findViewById(R.id.item_number_edit);
        mQuantity= rootView.findViewById(R.id.item_quantity_edit);
        mPrice= rootView.findViewById(R.id.item_price_edit);
        mLocation= rootView.findViewById(R.id.item_location_edit);
        mItemValue = rootView.findViewById(R.id.item_value);

        String quantityText = mQuantity.getText().toString();
        String priceText = mPrice.getText().toString();

        try {
            double quantity = Double.parseDouble(quantityText);
            double price = Double.parseDouble(priceText);

            double value = CalculateValue(quantity, price);

            mItemValue.setText(value + CURRENCY);

            mItemValue.setText(value + CURRENCY);
        } catch (NumberFormatException e) {

        }
        return rootView;
    }

    public void onCheckItemClick() {
        itemName = mItemName.getText().toString();
        itemDescription = mDescription.getText().toString();
        itemNumber = mItemNumber.getText().toString();
        itemQuantity = mQuantity.getText().toString();
        itemPrice = mPrice.getText().toString();
        itemLocation = mLocation.getText().toString();


    }


    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater menuInflater) {

        menuInflater.inflate(R.menu.task_bar, menu);

        // presets visibility for icons
        menu.findItem(R.id.search).setVisible(false);
        menu.findItem(R.id.delete).setVisible(false);
        menu.findItem(R.id.edit).setVisible(false);
        menu.findItem(R.id.logout).setVisible(false);
        menu.findItem(R.id.check).setVisible(true);
        menu.findItem(R.id.close).setVisible(true);
        menu.findItem(R.id.back).setVisible(true);
        menu.findItem(R.id.settings).setVisible(false);
    }

    private double CalculateValue(double quantity, double price) {
        return price * quantity;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == R.id.back || item.getItemId() == R.id.close) {
            String dialogTitle = "Close";
            String dialogMessage = "Close without Saving";
            String dialogPositive = "Yes";
            String dialogNegative = "No";

            AddEditDialog dialog = new AddEditDialog(dialogTitle, dialogMessage, dialogPositive, dialogNegative);
            dialog.setDialogListener(new DialogListener() {
                @Override
                public void onExitPositiveClick() {
                    // Return to inventory list
                    FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();
                    fragmentManager.popBackStack();

                }
                @Override
                public void onExitNegativeClick() {
                    // Continue editing
                }
            });
            dialog.show(getActivity().getSupportFragmentManager(), "ExitDialog");

            return true;
        } else if (item.getItemId() == R.id.check) {
            Toast.makeText(requireContext(), "Item saved", Toast.LENGTH_SHORT).show();
            onCheckItemClick();
            ItemsDatabase itemsDatabase = new ItemsDatabase(getContext());
         //   itemsDatabase.insertTestItem();
            itemsDatabase.insertItem(createNewItem());

            FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();
            fragmentManager.popBackStack();
            // save new item
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public Item createNewItem() {
        long number = Long.parseLong(itemNumber);
        int quantity = Integer.parseInt(itemQuantity);
        double price = Double.parseDouble(itemPrice);
        Item item = new Item(itemName, itemDescription, number, quantity, price, itemLocation);

        return item;
    }
}
