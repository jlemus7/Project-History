package com.zybooks.itemwise;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.provider.ContactsContract;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class AccountFragment extends Fragment {

    private TextView nameTextView;
    private TextView idTextView;
    private TextView phoneTextView;
    private TextView emailTextView;
    private boolean isAccountCreated = false;
    private Button createAccountButton;
    private static final String PREFS_NAME = "MyPrefsFile";


    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_account, container, false);
        setHasOptionsMenu(true);

        nameTextView = rootView.findViewById(R.id.name_edit);
        idTextView = rootView.findViewById(R.id.id_edit);
        phoneTextView = rootView.findViewById(R.id.phone_edit);
        emailTextView = rootView.findViewById(R.id.email_edit);

        UsersDatabase usersDatabase = new UsersDatabase(getContext());
        SharedPreferences settings = requireContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        User user = null;
        String userId = settings.getString("userId", "");
        user = usersDatabase.getUserData();

        if (user != null) {
            nameTextView.setText(user.getFirstName() + " " + user.getLastName());
            idTextView.setText(userId);
            phoneTextView.setText(user.getPhoneNumber());
            emailTextView.setText(user.getEmail());
        }

        return rootView;
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater menuInflater) {

        menuInflater.inflate(R.menu.task_bar, menu);


        // presets visibility for icons
        menu.findItem(R.id.search).setVisible(false);
        menu.findItem(R.id.delete).setVisible(false);
        menu.findItem(R.id.edit).setVisible(true);
        menu.findItem(R.id.logout).setVisible(true);
        menu.findItem(R.id.check).setVisible(false);
        menu.findItem(R.id.close).setVisible(false);
        menu.findItem(R.id.back).setVisible(false);
        menu.findItem(R.id.settings).setVisible(true);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == R.id.edit) {
         //   Toast.makeText(requireContext(), "Go to settings", Toast.LENGTH_SHORT).show();

            FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

            EditProfileFragment editProfileFragment = new EditProfileFragment();
            fragmentTransaction.replace(R.id.nav_host_fragment, editProfileFragment, "EditProfileFragment");
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();

            return true;
        } else if (item.getItemId() == R.id.settings) {

            FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

            SettingsFragment settingsFragment = new SettingsFragment();
            fragmentTransaction.replace(R.id.nav_host_fragment, settingsFragment, "SettingsFragment");
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();
            return true;
        } else if (item.getItemId() == R.id.logout) {

            Intent intent = new Intent(requireContext(), LoginActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}