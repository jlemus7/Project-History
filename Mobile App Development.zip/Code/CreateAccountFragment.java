package com.zybooks.itemwise;

import android.Manifest;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.util.List;
import java.util.Random;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class CreateAccountFragment extends Fragment {

    private Button createAccountButton;
    private EditText mFirstNameEditText;
    private EditText mLastNameEditText;
    private EditText mPhoneNumberEditText;
    private EditText mEmailEditText;
    private EditText mPasswordEditText;
    private EditText mConfirmPasswordEditText;
    private String hint = "Must be at least 8 char";
    private String password;
    private String confirmedPassword;
    private static final String PREFS_NAME = "MyPrefsFile";
    private String userId;
    private boolean sendSMS = false;
    private static final int REQUEST_SMS_PERMISSION = 156;
    private static final int REQUEST_REVOKE_SMS_PERMISSION = 898;

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        View rootView = inflater.inflate(R.layout.fragment_create_account, container, false);

        mFirstNameEditText = rootView.findViewById(R.id.first_text);
        mLastNameEditText = rootView.findViewById(R.id.last_text);
        mPhoneNumberEditText = rootView.findViewById(R.id.phone_text);
        mEmailEditText = rootView.findViewById(R.id.email_text);
        mPasswordEditText = rootView.findViewById(R.id.password_text);
        mConfirmPasswordEditText = rootView.findViewById(R.id.confirm_password_text);
        mPasswordEditText.setHint(hint);
        createAccountButton = rootView.findViewById(R.id.create_button);

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                // Check if all EditText fields have content
                boolean allFieldsNotEmpty = !mFirstNameEditText.getText().toString().isEmpty()
                        && !mLastNameEditText.getText().toString().isEmpty()
                        && !mPhoneNumberEditText.getText().toString().isEmpty()
                        && !mEmailEditText.getText().toString().isEmpty()
                        && !mPasswordEditText.getText().toString().isEmpty()
                        && !mConfirmPasswordEditText.getText().toString().isEmpty();


                if (mPasswordEditText.getText().toString().length() < 8) {
                    mPasswordEditText.setHintTextColor(ContextCompat.getColor(getContext(), R.color.red));

                } else {
                    // Enable the button only if all fields are not empty
                    password = mPasswordEditText.getText().toString();
                    confirmedPassword = mConfirmPasswordEditText.getText().toString();
                    if (!password.equals(confirmedPassword)) {
                        mConfirmPasswordEditText.setHint("Passwords do not match");
                        mConfirmPasswordEditText.setHintTextColor(ContextCompat.getColor(getContext(), R.color.red));
                        createAccountButton.setEnabled(!allFieldsNotEmpty);
                    } else {
                        createAccountButton.setEnabled(allFieldsNotEmpty);
                    }
                }
            }
        };

// Add the same TextWatcher to each EditText
        mFirstNameEditText.addTextChangedListener(textWatcher);
        mLastNameEditText.addTextChangedListener(textWatcher);
        mPhoneNumberEditText.addTextChangedListener(textWatcher);
        mEmailEditText.addTextChangedListener(textWatcher);
        mPasswordEditText.addTextChangedListener(textWatcher);
        mConfirmPasswordEditText.addTextChangedListener(textWatcher);


        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onCreateAccountClick();
            }
        });

        // Inflate the layout for this fragment
        return rootView;
    }

    public void onCreateAccountClick() {

        userId = getRandomId();
        storeUserInformation();
        // TODO: fix encryption

        // create a new instance with empty data.
        Intent intent = new Intent(requireContext(), MainActivity.class);
        startActivity(intent);

        // Update the flag to indicate that an account has been created
        SharedPreferences settings = requireContext().getSharedPreferences(PREFS_NAME, 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.putBoolean("isAccountCreated", true);
        editor.putString("userId", userId);
        editor.putInt("lowBound", 0);
        editor.putBoolean("sendSms", sendSMS);
        editor.apply();
    }

    public void storeUserInformation() {
        UsersDatabase usersDatabase = new UsersDatabase(getContext());
        String first = mFirstNameEditText.getText().toString();
        String last = mLastNameEditText.getText().toString();
        String phone = mPhoneNumberEditText.getText().toString();
        String email = mEmailEditText.getText().toString();
        String password = mPasswordEditText.getText().toString();
        User user = new User(first, last, phone, email, password);

        usersDatabase.insertUser(user);
    }


    public String getRandomId() {
        String id = "";

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyMMddHHmmss");
        String formattedDateTime = now.format(formatter);

        long timestamp = Long.parseLong(formattedDateTime);
        long randomSuffix = new Random().nextInt(900000) + 100000;
        long randomId =  (long) (timestamp + randomSuffix);

        id = String.format("%06d", randomId % 1000000);

        return id;
    }



}