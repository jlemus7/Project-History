package com.zybooks.itemwise;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.view.LayoutInflater;
import android.view.ViewGroup;


public class LoginFragment extends Fragment {

    private EditText mEmailEditText;
    private EditText mPasswordEditText;
    private String mEmail;
    private String mPassword;
    private User user;
    private static final String PREFS_NAME = "MyPrefsFile";

    Button loginButton;
    Button createAccountButton;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_login, container, false);

        // set text
        mEmailEditText = rootView.findViewById(R.id.email_text);
        mPasswordEditText = rootView.findViewById(R.id.password_text);

        loginButton = rootView.findViewById(R.id.login_button);
        createAccountButton = rootView.findViewById(R.id.create_account_button);


        // Allows only one user per device
        SharedPreferences settings = requireContext().getSharedPreferences(PREFS_NAME, 0);
        boolean isAccountCreated = settings.getBoolean("isAccountCreated", false);

        if (isAccountCreated) {
            createAccountButton.setVisibility(View.GONE); // Hide the button
        } else {
            createAccountButton.setVisibility(View.VISIBLE); // Show the button
        }


        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onLoginClick();
            }
        });

        createAccountButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                onCreateAccountClick();
            }
        });

        return rootView;
    }

    public void onLoginClick() {
        mEmail = mEmailEditText.getText().toString().trim();
        mPassword = mPasswordEditText.getText().toString().trim();

        UsersDatabase usersDatabase = new UsersDatabase(getContext());
        user = usersDatabase.getUserData();

        if (mEmail.isEmpty() && mPassword.isEmpty()) {
            // make login button unavailable
            mEmailEditText.setHintTextColor(ContextCompat.getColor(getContext(), R.color.red));
            mPasswordEditText.setHintTextColor(ContextCompat.getColor(getContext(), R.color.red));

        } else {        // user entered data

            if (user == null){
                // Inform the user of incorrect login
                Toast.makeText(requireContext(), "login incorrect", Toast.LENGTH_LONG).show();
                mEmailEditText.setTextColor(ContextCompat.getColor(getContext(), R.color.red));
                mPasswordEditText.setTextColor(ContextCompat.getColor(getContext(), R.color.red));

            } else if(mEmail.equals(user.getEmail()) && mPassword.equals(user.getPassword())) {       // user user Exists
                Intent intent = new Intent(requireContext(), MainActivity.class);
                startActivity(intent);
            }

        }
    }

    public void onCreateAccountClick() {

        FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        CreateAccountFragment createAccountFragment = new CreateAccountFragment();
        fragmentTransaction.replace(R.id.nav_host_login_fragment, createAccountFragment, "CreateAccountFragment");
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }
}