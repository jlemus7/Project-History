package com.zybooks.itemwise;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.ActionMode;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class InventoryFragment extends Fragment {
    private List<Item> itemList = new ArrayList<>();
    private ActionMode actionMode;
    private long itemNumber;
    private RecyclerView recyclerView;
    private ItemAdapter itemAdapter;


    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){

        View rootView = inflater.inflate(R.layout.fragment_inventory, container, false);
        setHasOptionsMenu(true);

        FloatingActionButton mAddItemButton = rootView.findViewById(R.id.add_item);
        mAddItemButton.setOnClickListener(view -> addItemClick());

        populateList();
        recyclerView = rootView.findViewById(R.id.item_list);

        itemAdapter = new ItemAdapter(itemList, getContext());

        recyclerView.setAdapter(itemAdapter);


        itemAdapter.setOnItemClickListener(new ItemAdapter.ItemClickListener() {
            @Override
            public void onItemLongClick(int position) {
                if (actionMode != null) {
                    return;
                }
                actionMode = requireActivity().startActionMode(actionModeCallback);
            }

            @Override
            public void onItemClick(int position) {
                Item itemClicked = itemList.get(position);

                Bundle bundle = new Bundle();
                bundle.putParcelable("selectedItem", itemClicked);

                ItemDetailsFragment itemDetailsFragment = new ItemDetailsFragment();
                itemDetailsFragment.setArguments(bundle);

                FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.nav_host_fragment, itemDetailsFragment, "ItemDetailsFragment");
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });
        return rootView;
    }


    private ActionMode.Callback actionModeCallback = new ActionMode.Callback() {
        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            MenuInflater inflater = mode.getMenuInflater();
            inflater.inflate(R.menu.task_bar, menu);
            // presets visibility for icons
            menu.findItem(R.id.search).setVisible(false);
            menu.findItem(R.id.delete).setVisible(true);
            menu.findItem(R.id.edit).setVisible(true);
            menu.findItem(R.id.logout).setVisible(false);
            menu.findItem(R.id.check).setVisible(false);
            menu.findItem(R.id.close).setVisible(false);
            menu.findItem(R.id.back).setVisible(false);
            menu.findItem(R.id.settings).setVisible(true);

            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            // Handle contextual menu item clicks here
            if (item.getItemId() == R.id.delete) {
                itemNumber = itemAdapter.getItemNumber();
                deleteItem(itemAdapter);
                mode.finish();

            } else if (item.getItemId() == R.id.edit) {

            }
            return true;
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {
            actionMode = null;
            recyclerView.getAdapter().notifyDataSetChanged();

        }
    };

    private void addItemClick() {
        // handle click
        FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        AddItemFragment addItemFragment = new AddItemFragment();
        fragmentTransaction.replace(R.id.nav_host_fragment, addItemFragment, "AddItemFragment");
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater menuInflater) {

        menuInflater.inflate(R.menu.task_bar, menu);

        // presets visibility for icons
        menu.findItem(R.id.search).setVisible(true);
        menu.findItem(R.id.delete).setVisible(false);
        menu.findItem(R.id.edit).setVisible(false);
        menu.findItem(R.id.logout).setVisible(false);
        menu.findItem(R.id.check).setVisible(false);
        menu.findItem(R.id.close).setVisible(false);
        menu.findItem(R.id.back).setVisible(false);
        menu.findItem(R.id.settings).setVisible(false);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        return super.onOptionsItemSelected(item);
    }
    public void populateList() {

        ItemsDatabase itemsDatabase = new ItemsDatabase(getContext());
        itemList = itemsDatabase.getAllItems();
    }


    public void deleteItem(ItemAdapter itemAdapter) {
        itemAdapter.notifyDataSetChanged();
        ItemsDatabase itemsDatabase = new ItemsDatabase(getContext());
        itemsDatabase.deleteItem(itemNumber);

        ListIterator<Item> iterator = itemList.listIterator();
        int positionToRemove = -1;

        while (iterator.hasNext()) {
            Item thisItem = iterator.next();
            if (thisItem.getItemNumber() == itemNumber) {
                positionToRemove = itemList.indexOf(thisItem);
                iterator.remove();
                break;
            }
        }

    }

}