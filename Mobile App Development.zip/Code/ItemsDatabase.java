package com.zybooks.itemwise;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class ItemsDatabase  extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "items.db";
    private static final int VERSION = 1;

    public ItemsDatabase (Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class ItemsTable {
        private static final String TABLE = "items";
        private static final String COL_NAME = "name";
        private static final String COL_DESCRIPTION = "description";
        private static final String COL_ITEM_NUMBER = "item_number";
        private static final String COL_QUANTITY = "quantity";
        private static final String COL_PRICE = "price";
        private static final String COL_LOCATION = "location";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + ItemsTable.TABLE + " (" +
                ItemsTable.COL_NAME + " TEXT, " +
                ItemsTable.COL_DESCRIPTION + " TEXT, " +
                ItemsTable.COL_ITEM_NUMBER + " LONG, " +
                ItemsTable.COL_QUANTITY + " INT, " +
                ItemsTable.COL_PRICE + " DOUBLE, " +
                ItemsTable.COL_LOCATION + " TEXT)");
    }


    public void insertItem(Item item) {

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ItemsDatabase.ItemsTable.COL_NAME, item.getName());
        values.put(ItemsDatabase.ItemsTable.COL_DESCRIPTION, item.getDescription());
        values.put(ItemsDatabase.ItemsTable.COL_ITEM_NUMBER, item.getItemNumber());
        values.put(ItemsDatabase.ItemsTable.COL_QUANTITY, item.getQuantity());
        values.put(ItemsDatabase.ItemsTable.COL_PRICE, item.getPrice());
        values.put(ItemsDatabase.ItemsTable.COL_LOCATION, item.getLocation());

        db.insert(ItemsDatabase.ItemsTable.TABLE, null, values);
        db.close();
    }

    public void deleteItem(long itemNumber) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(ItemsTable.TABLE, ItemsTable.COL_ITEM_NUMBER + " = ?", new String[]{String.valueOf(itemNumber)});
        db.close();
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + ItemsDatabase.ItemsTable.TABLE);
        onCreate(db);
    }

    public List<Item> getAllItems() {
        List<Item> itemList = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        String[] columns = {
                ItemsTable.COL_NAME,
                ItemsTable.COL_DESCRIPTION,
                ItemsTable.COL_ITEM_NUMBER,
                ItemsTable.COL_QUANTITY,
                ItemsTable.COL_PRICE,
                ItemsTable.COL_LOCATION
        };

        Cursor cursor = db.query(
                ItemsTable.TABLE,
                columns,
                null,
                null,
                null,
                null,
                null
        );

        while (cursor.moveToNext()) {
            int nameIndex = cursor.getColumnIndex(ItemsTable.COL_NAME);
            int descriptionIndex = cursor.getColumnIndex(ItemsTable.COL_DESCRIPTION);
            int numberIndex = cursor.getColumnIndex(ItemsTable.COL_ITEM_NUMBER);
            int quantityIndex = cursor.getColumnIndex(ItemsTable.COL_QUANTITY);
            int priceIndex = cursor.getColumnIndex(ItemsTable.COL_PRICE);
            int locationIndex = cursor.getColumnIndex(ItemsTable.COL_LOCATION);
            if (nameIndex == -1) {
                // Handle error, log, or skip this row
                continue;
            }

            String name = cursor.getString(nameIndex);
            String description = cursor.getString(descriptionIndex);
            long itemNumber = cursor.getLong(numberIndex);
            int quantity = cursor.getInt(quantityIndex);
            double price = cursor.getDouble(priceIndex);
            String location = cursor.getString(locationIndex);
            Item item = new Item(name, description, itemNumber, quantity, price, location);

            itemList.add(item);
        }

        cursor.close();
        db.close();

        return itemList;
    }
}
