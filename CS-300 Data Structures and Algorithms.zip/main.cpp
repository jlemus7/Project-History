/*
* Name: Course Planner
* Author: Jose Lemus
* Date: 06/18/2023
*/

#include <iostream>

#include "BinarySearchTree.h"
#include "Ivalidate.h"


int main() {

	// initialize variables
	int menuInput = 0;
	string courseId;
	string fileName;
	bst::BinarySearchTree* bst;
	bst = new bst::BinarySearchTree();

	bst::Course course;

	cout << "\nWelcome to Course Planner.\n" << endl;

	while (menuInput != 9) {
		bst::Menu();
		cout << endl;
		menuInput = ival::getDouble("What would you like to do? ", 1, 10);
		//cout << endl;
		switch (menuInput)
		{
		case 1:
			// load courses
		
			// get file name from the user
			cout << "Enter file name: ";
			cin >> fileName;

			delete bst;		// deletes current instance of bst and frees memory

			bst = new bst::BinarySearchTree();
			bst::LoadCources(bst, fileName);
			cout << endl;
			break;

		case 2:
			// print all courses
			cout << "Here is the list of all courses." << endl;
			cout << endl;
			bst->PrintAll();
			cout << endl;
			break;

		case 3:
			// print course info
			cout << "Enter course ID: ";
			cin >> courseId;
			cout << endl;
			bst->PrintCourse(ival::toUpper(courseId));
			break;

		default:
			// inputs between 4 and 8
			if (menuInput != 9) {
				cout << menuInput << " is not an option.\n" << endl;
			}
			break;
		}
	}
	cout << "\nThank you for using course planner!" << endl;
	cout << "Good Bye!" << endl;


	return 0;
}