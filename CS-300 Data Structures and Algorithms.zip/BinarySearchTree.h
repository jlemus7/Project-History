/*
* Name: Course Planner
* Author: Jose Lemus
* Date: 06/18/2023
*/

#pragma once
#ifndef BINARYSEARCHTREE_H
#define BINARYSEARCHTREE_H

#include <string>
#include <vector>

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

namespace bst {

	// structure that holds course information
	struct Course {
		string courseId;
		string courseName;

		vector<string> prerequisites;

		Course();
	};

	// Internal structure of a tree node
	struct Node {
		Course course;
		Node* left;
		Node* right;

		// default constructor
		Node();
		// initialize node with a course
		Node(Course aCourse);
	};


	class BinarySearchTree {

	private:
		Node* root;
		void addNode(Node* node, Course course);
		void inOrder(Node* node);

	public:
		BinarySearchTree();
		void deleteTree(Node* node);
		virtual ~BinarySearchTree();
		void CreateCourse(string fileInput);
		void InsertCourse(Course course);
		Course Search(string courseId);
		void PrintCourse(string courseId);
		void PrintAll();

	};

	void Menu();
	void LoadCources(BinarySearchTree* bst, string fileName);

}
#endif // !BINARYSEARCHTREE_H
