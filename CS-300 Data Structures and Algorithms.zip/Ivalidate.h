/*
* Name: Course Planner
* Author: Jose Lemus
* Date: 02/05/2023
*/

#pragma once
#ifndef IVALIDATE_H
#define IVALIDATE_H

#include <string>

using namespace std;

namespace ival {

	double doubleValidation(const string& t_prompt);

	double getDouble(const string& t_prompt, int t_min, int t_max);

	string toUpper(string userInput);

}
#endif // !IVALIDATE_H
