package test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import model.Task;
import model.TaskService;

class TaskTest {
	
	TaskService ts = new TaskService();
	List<Task> testList = new ArrayList();
	
	@Test
	@DisplayName("Test task object not null")
	void testTaskObject() {
		Task task = new Task("1234567891", "task name.", "task description here");
		assertNotNull(task);
	}
	
	
	// Testing task ID requirements
	@Test
	@DisplayName("Test throws exception on null Id")
	void testThrowsExceptionOnNullId() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task(null, "task name",  "task description");
		});
	}
	
	
	@Test
	@DisplayName("Test id is not null")
	void testIdIsNotNull() {
		Task task = new Task("1234567891", "task name.", "task description here");
		assertNotNull(task.getId());
	}
	
	
	@Test
	@DisplayName("Test throws exception on id too long")
	void testThrowsExceptionOnInvalidIdLength() {
		assertThrows(IllegalArgumentException.class, () -> {
			// task id length = 11.
			new Task("12345678910", "task name", "task description here");
		
		});
	}
	
	
	@Test
	@DisplayName("Test id max acceptable length = 10")
	void testIdLengthLimit() {
		// task id length = 10.
		Task task = new Task("1234567891", "task name", "task description here");
		assertTrue(task.getId().length() == 10);
	}
	
	
	@Test
	@DisplayName("Test id accepts length < 10")
	void testIdAcceptsShortString() {
		// task id length = 9.
		Task task = new Task("123456789", "task name", "task description here");
		assertTrue(task.getId().length() < 10);
	}
	
	
	@Test
	@DisplayName("Test ID uniqueness")
	void testIdUniqueness() {
		testList.add(new Task(ts.createUniqueId(), "Task name", "Task description"));
		testList.add(new Task(ts.createUniqueId(), "Task name", "Task description"));
		testList.add(new Task(ts.createUniqueId(), "Task name", "Task description"));
		testList.add(new Task(ts.createUniqueId(), "Task name", "Task description"));
		
		assertAll(
				() -> assertTrue(!testList.get(0).getId().equals(testList.get(1).getId())),
				() -> assertTrue(!testList.get(0).getId().equals(testList.get(2).getId())),
				() -> assertTrue(!testList.get(0).getId().equals(testList.get(3).getId())),
				() -> assertTrue(!testList.get(1).getId().equals(testList.get(2).getId())),
				() -> assertTrue(!testList.get(1).getId().equals(testList.get(3).getId())),
				() -> assertTrue(!testList.get(2).getId().equals(testList.get(3).getId())));
	}

	
	// testing task name requirements
	@Test
	@DisplayName("Test throws exception on null name")
	void testThrowsExceptionOnNullName() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("123456789", null, "task description");
		});
	}
	
	
	@Test
	@DisplayName("Test task name not null")
	void testNameNotNull() {
		Task task = new Task("123456789", "task name", "task description here");
		assertNotNull(task.getName());
	}
	
	
	@Test
	@DisplayName("Test throws exception on name too long")
	void testThrowsExceptionOnNameTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			// task name length = 21.
			new Task("123456789", "task name too long...", "task description");
		});
	}
	

	@Test
	@DisplayName("Test name max acceptable length = 20")
	void testMaxAcceptableNameLength() {
		// task name length = 20.
		Task task = new Task("1234567891", "task name goes here.", "task description here");
		assertTrue(task.getName().length() == 20);
	}
	
	
	@Test
	@DisplayName("Test name accepts length < 20")
	void testNameAcceptsShortString() {
		// task name length = 19.
		Task task = new Task("1234567891", "task name goes here", "task description here");
		assertTrue(task.getName().length() < 20);
	}
	
	
	// Test task description requirements
	@Test
	@DisplayName("Test throws exception on null description")
	void testThrowsExceptionOnNullDescription() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Task("1234567", "task name", null);
		});
	}
	
	
	@Test
	@DisplayName("Test description is not null")
	void testDescriptionNotNull() {
		Task task = new Task("1234567891", "task name goes here", "task description here");
		assertNotNull(task.getDescription());
	}
	
	
	@Test
	@DisplayName("Test  throws exception on description too long")
	void testThrowsExceptionOnDescriptionTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			// Task description length = 51.
			new Task("123456789", "task name here", "description is too long here. size must be <= 50...");
		});
	}
	
	
	@Test
	@DisplayName("Test max acceptable description length = 50")
	void testMaxAcceptableDescriptionLength() {
		// task description length = 50.
		Task task = new Task("1234567891", "task name", "this is the task description. here is long enough.");
		assertTrue(task.getDescription().length() == 50);
	}
	
	
	@Test
	@DisplayName("Test description accepts length < 50")
	void testDescriptionAcceptsShortString() {
		// task description length = 47.
		Task task = new Task("1234567891", "task name", "this is the task description. short description");
		assertTrue(task.getDescription().length() < 50);
	}
	
}
