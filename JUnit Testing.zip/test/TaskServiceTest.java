package test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import model.Task;
import model.TaskService;

class TaskServiceTest {
	
	 private TaskService taskService;
	 private String taskId;
	
	// [NOTE] the task ID is inherently not updatable once a task object is created.
	@BeforeEach
	void addTaskObjectsIntoList() {
		taskService = new TaskService();
		Task task = new Task(taskService.createUniqueId(), "task name", "task description");
		taskService.getTaskList().add(new Task(taskService.createUniqueId(), "task name", "task description"));
		taskService.getTaskList().add(new Task(taskService.createUniqueId(), "task name", "task description"));
		taskService.getTaskList().add(new Task(taskService.createUniqueId(), "task name", "task description"));
		taskService.getTaskList().add(task);
		taskId = task.getId();
		}
	
	// test adding a task object
	@Test
	@DisplayName("Test throws exception when inserting a null object")
	void testAddNullTaskThrowsExceptionAndLeavesListUnchanged() {
		assertAll(
				() -> assertThrows(IllegalArgumentException.class, () -> {
					taskService.addTask(null);}),
				() -> assertTrue(taskService.getTaskList().size() == 4)); // ensures list remains unchanged
	}
	
	
	@Test
	@DisplayName("Test task object not null")
	void testTaskObjectNotNull() {
		assertNotNull(new Task(taskService.createUniqueId(), "task name", "task description"));
	}
	
	
	@Test
	@DisplayName("Test successfully adding a task")
	void testSuccessfulTaskAddition() {
		
		taskService.addTask(new Task(taskService.createUniqueId(), "task name", "task description"));
		assertTrue(taskService.getTaskList().size() == 5); 	// ensures list grows by 1
	}
	
	
	@Test
	@DisplayName("Test thows exception on non unique ID")
	void testAddingNonUniqueTaskIDThrowsExceptionAndLeavesListUnchanged() {
		
		Task task = new Task(taskId, "name", "Description");
		
		assertAll (
				() -> assertThrows(IllegalArgumentException.class, () -> {
					taskService.addTask(task);}),
				() -> assertTrue(taskService.getTaskList().size() == 4)); 	// ensures list remains unchanged
	}
	
	
	// Test deleting a task
	@Test
	@DisplayName("Test throws exception when removing non existing task")
	void testRemoveNonExistingTaskThrowsExceptionAndLeavesListUnchanged() {
		assertAll(
				() -> assertThrows(IllegalArgumentException.class, () -> {
					taskService.deleteTask("123456789");}),
				() -> assertTrue(taskService.getTaskList().size() == 4));   // ensures list remains unchanged
	}
	
	
	@Test
	@DisplayName("Test successfully removing a task")
	void testSuccessfulTaskDeletion() {
		assertTrue(taskService.getTaskList().size() == 4); // ensures task object is added into list
		
		taskService.deleteTask(taskId);
		assertTrue(taskService.getTaskList().size() == 3); // ensures task object is successfully deleted
	}
	
	
	// test updating the task name
	@Test
	@DisplayName("Test throws exception on name update of non existing task")
	void testNameUpdateThrowsExceptionOnNonExistingTaskAndLeavesListUnchanged() {
		assertThrows(IllegalArgumentException.class, () -> {
			taskService.updateTaskName("123456789", "new task name");});
	}
	
	
	@Test
	@DisplayName("Test updateTaskName follows string length requirements")
	void testUpdateTaskNameFollowRangeRequirements() {
		assertAll(
				() -> assertThrows(IllegalArgumentException.class, () -> { 		// throws exception on null name
					taskService.updateTaskName(taskId, null);}),
				() -> { taskService.updateTaskName(taskId, "new task name");
				assertNotNull(taskService.getTaskList().get(3).getName());}, 	// task name is not null
				() -> assertThrows(IllegalArgumentException.class, () -> { 		// name cannot be longer than 20 characters
					taskService.updateTaskName(taskId, "task name too long...");}),
				() -> { taskService.updateTaskName(taskId, "new task name here..");
				assertTrue(taskService.getTaskList().get(3).getName().length() == 20);}, 	// name field must be 20 character or less
				() -> { taskService.updateTaskName(taskId, "new task name here.");
				assertTrue(taskService.getTaskList().get(3).getName().length() < 20);});
	}
	
	
	@Test
	@DisplayName("Test successfully updating a task name")
	void testSuccessfulTaskNameUpdate() {
		taskService.updateTaskName(taskId, "new task name");
		
		assertTrue(taskService.getTaskList().get(3).getName().equals("new task name"));
	}
	
	
	// test updating a task description
	@Test
	@DisplayName("Test throws exception on description update of non existing task")
	void testDescriptionUpdateThrowsExceptionOnNonExistingTaskAndLeavesListUnchanged() {
		assertThrows(IllegalArgumentException.class, () -> {
			taskService.updateTaskDescription("123456789", "new task description");});
	}
	
	
	@Test
	@DisplayName("Test successfully updating a task description")
	void testSuccessfulTaskDescriptionUpdate() {
		taskService.updateTaskDescription(taskId, "new task description");
		
		assertTrue(taskService.getTaskList().get(3).getDescription().equals("new task description"));
	}
	
	
	@Test
	@DisplayName("Test updateTaskDescription follows string length requirements")
	void testUpdateTaskDescriptionFollowRangeRequirements() {
		assertAll(
				() -> assertThrows(IllegalArgumentException.class, () -> { 	// throws exception on null new description
					taskService.updateTaskDescription(taskId, null);}),
				() -> { taskService.updateTaskDescription(taskId, "this is the task description. here is long enough"); 	// task description is not null
				assertNotNull(taskService.getTaskList().get(3).getDescription());},
				() -> assertThrows(IllegalArgumentException.class, () -> { 	// description cannot be longer than 50 characters
					taskService.updateTaskDescription(taskId, "description is too long here. size must be <= 50...");}),
				() -> { taskService.updateTaskDescription(taskId, "this is the task description. here is long enough."); 	// description field must be 50 character or less
				assertTrue(taskService.getTaskList().get(3).getDescription().length() == 50);},
				() -> { taskService.updateTaskDescription(taskId, "this is the task description. here is long enough");
				assertTrue(taskService.getTaskList().get(3).getDescription().length() < 50);
				});
	}
	
	

}
