package test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import model.Appointment;
import model.AppointmentService;

class AppointmentTest {
	
	List<Appointment> testList = new ArrayList();
	AppointmentService as = new AppointmentService();

	@Test
	@DisplayName("Test appointment object not null")
	void testAppNotNull() throws ParseException {
		assertNotNull(new Appointment("123456789", "2023-12-24", "app description here"));
	}

	
	// testing ID requirements
	@Test
	@DisplayName("Test throws exception on null Id")
	void testNullId() {
		assertThrows(IllegalArgumentException.class, () -> {
	        new Appointment (null, "2023-12-24", "app description here");
	        });
	}
	
	
	@Test
	@DisplayName("Test id is not null")
	void testIdIsNotNull() throws ParseException {
		Appointment appointment = new Appointment("123456789", "2023-12-24", "app description here");
		assertNotNull(appointment.getId());
	}
	
	
	@Test
	@DisplayName("Test throws exception on id too long")
	void testIdLengthTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
	        new Appointment ("12345678901", "2023-12-24", "app description here");
	        });
	}
	
	
	@Test
	@DisplayName("Test id max acceptable length = 10")
	void testMaxAcceptableIdLength() throws ParseException {
		
		Appointment appointment = new Appointment("1234567899", "2023-12-24", "app description here");
		assertTrue(appointment.getId().length() == 10);
	}
	
	
	@Test
	@DisplayName("Test id accepts length < 10")
	void testAcceptableIdLength() throws ParseException {
		
		Appointment appointment = new Appointment("123456789", "2023-12-24", "app description here");
		assertTrue(appointment.getId().length() < 10);
	}
	
	
	@Test
	@DisplayName("Test ID uniqueness")
	void testAppointmentIDUniquenessAfterMultipleAdds() throws ParseException {
		testList.add(new Appointment(as.createUniqueId(), "2023-12-24", "app description here"));
		testList.add(new Appointment(as.createUniqueId(), "2023-11-24", "app description"));
		testList.add(new Appointment(as.createUniqueId(), "2023-11-24", "description"));
		testList.add(new Appointment(as.createUniqueId(), "2023-11-24", "description"));
		
		assertAll(
			    () -> assertTrue(!testList.get(0).getId().equals(testList.get(1).getId())),
			    () -> assertTrue(!testList.get(0).getId().equals(testList.get(2).getId())),
			    () -> assertTrue(!testList.get(0).getId().equals(testList.get(3).getId())),
			    () -> assertTrue(!testList.get(1).getId().equals(testList.get(2).getId())),
			    () -> assertTrue(!testList.get(1).getId().equals(testList.get(3).getId())),
			    () -> assertTrue(!testList.get(2).getId().equals(testList.get(3).getId())));
	}
	
	
	// testing date requirements
	// [NOTE] date format not specified. Selected date format yyyy-MM-dd
	@Test
	@DisplayName("Test throws exception on null date")
	void testNullDate() {
		assertThrows(IllegalArgumentException.class, () -> {
	        new Appointment ("123456789", null, "app description here");
	        
	        });
	}
	
	
	@Test
	@DisplayName("Test date field is not null")
	void testDateNotNull() throws ParseException {
		Appointment appointment = new Appointment("123456789", "2023-12-24", "app description here");
		assertTrue(appointment.getDate() != null);
	}
	
	
	@Test
	@DisplayName("Test throws exception on date too short")
	void testDateTooShort() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment ("123456789", "2024-1-24", "app description here");
		});
	}
	
	
	@Test
	@DisplayName("Test throws exception on date too long")
	void testDateTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment ("123456789", "2023-12-24-", "app description here");
		});
	}
	
	
	@Test
	@DisplayName("Test throws exception on invalid date format")
	void testInvalidFormat() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment ("123456789", "2023/12/24", "app description here");
		});
	}
	
	
	@Test
	@DisplayName("Test throws exception on past date")
	void testPastDates() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Appointment ("123456789", "2023-09-27", "app description here");
		});
	}
	
	
	@Test
	@DisplayName("Test throws parse exception on invalid input type")
	void testDateInvalidInputType() {
		assertThrows(ParseException.class, () -> {
			new Appointment ("123456789", "yyyy-mm-dd", "app description here");
		});
	}
	
	
	@Test
	@DisplayName("Test date length must be 10")
	void testValidLength() throws ParseException {
		Appointment appointment = new Appointment ("123456789", "2023-12-24", "app description here");
		
		assertTrue(appointment.getDate().length() == 10);
	}
	
	
	@Test
	@DisplayName("Test date is in the future")
	void testFutureDate() throws ParseException {
		Appointment appointment = new Appointment ("123456789", "2023-12-24", "app description here");
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		assertTrue(dateFormat.parse(appointment.getDate()).after(new Date()));
	}
	
	
	// testing description requirements
	@Test
	@DisplayName("Test throws exception on null description")
	void testNullDescription() {
		assertThrows(IllegalArgumentException.class, () -> {
	        new Appointment ("123456789", "2023-12-24", null);
	        });
	}
	
	
	@Test
	@DisplayName("Test description is not null")
	void testDescriptionNotNull() throws ParseException {
		Appointment appointment = new Appointment("123456789", "2023-12-24", "app description here");
		assertNotNull(appointment.getDescription());
	}
	
	
	@Test
	@DisplayName("Test thows exception on description too long")
	void testDescriptionTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
	        new Appointment ("123456789", "2023-12-24", "description is too long here. size must be <= 50...");
	        });
	}
	
	
	@Test
	@DisplayName("Test description max acceptable length = 50")
	void testDescriptionMaxAcceptableLength() throws ParseException {
	        Appointment appointment = new Appointment ("123456789", "2023-12-24", "this is the task description. here is long enough.");
	        
	        assertTrue(appointment.getDescription().length() == 50);
	        
	}
	
	
	@Test
	@DisplayName("Test description accepts length < 50")
	void testAcceptsShortDescriptionLength() throws ParseException {
	        Appointment appointment = new Appointment ("123456789", "2023-12-24", "this is the task description.");
	        
	        assertTrue(appointment.getDescription().length() < 50);
	        
	}
}

