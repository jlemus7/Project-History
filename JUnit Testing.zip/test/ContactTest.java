package test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import model.Contact;
import model.ContactService;

@DisplayName("Contact class test")
class ContactTest {
	
	List<Contact> testList = new ArrayList();
	ContactService cs = new ContactService();
	
	// Testing ID requirements
	@Test
	@DisplayName("Test contact id is not null")
	void testContactObject() {
		Contact contact = new Contact("1234567890", "John", "Smith", "1234567891", "123 main st");
		assertNotNull(contact.getId());
	}
	
	
	@Test
	@DisplayName("Test throws exception on null id")
	void testThrowsExceptionOnNullId() {
		assertThrows(IllegalArgumentException.class, () -> {
	        new Contact(null, "John", "Smith", "1234567890", "123 main st");
	    });
	}
	
	
	@Test
	@DisplayName("Test throws exception on id too long")
	void testThrowsExceptionOnIdTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("12345678901", "John", "Smith", "1234567890", "123 main st");	  
	        });
	}
	
	
	@Test
	@DisplayName("Test ID max acceptable length = 10")
	void testMaxAcceptableIdLength() {
		
		Contact contact = new Contact("1234567899", "John", "Smith", "1234567890", "123 main st");
		assertTrue(contact.getId().length() == 10);
	}
	
	
	@Test
	@DisplayName("Test ID accepts  < 10")
	void testAcceptsShortIds() {
		
		Contact contact = new Contact("123456789", "John", "Smith", "1234567890", "123 main st");
		assertTrue(contact.getId().length() < 10);
	}
	
	
	@Test
	@DisplayName("Test ID uniqueness")
	void testIdUniquenessAfterMultipleAdds() {
		testList.add(new Contact(cs.createUniqueId(), "John", "Smith", "1234567890", "123 main st"));
		testList.add(new Contact(cs.createUniqueId(), "John", "Smith", "1234567890", "123 main st"));
		testList.add(new Contact(cs.createUniqueId(), "John", "Smith", "1234567890", "123 main st"));
		testList.add(new Contact(cs.createUniqueId(), "John", "Smith", "1234567890", "123 main st"));
		
		assertAll(
				() -> assertTrue(!testList.get(0).getId().equals(testList.get(1).getId())),
				() -> assertTrue(!testList.get(0).getId().equals(testList.get(2).getId())),
				() -> assertTrue(!testList.get(0).getId().equals(testList.get(3).getId())),
				() -> assertTrue(!testList.get(1).getId().equals(testList.get(2).getId())),
				() -> assertTrue(!testList.get(1).getId().equals(testList.get(3).getId())),
				() -> assertTrue(!testList.get(2).getId().equals(testList.get(3).getId())));
		
	}
	
	
	// Testing contact first name requirements
	@Test
	@DisplayName("Test throws exception on null first name")
	void testThrowsExceptionOnNullFirst() {
		assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("1234567891", null, "Smith", "1234567890", "123 main st");
	        });
	}
	
	
	@Test
	@DisplayName("Test first name is not null")
	void testFirstNameNotNull() {
		Contact contact = new Contact("1234567890", "John", "Smith", "1234567891", "123 main st");
		assertNotNull(contact.getFirstName());
	}
	
	
	@Test
	@DisplayName("Test throws exception on first name too long")
	void testThrowsExceptionOnFirstNameTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("1234567891", "Samanthalia", "Smith", "1234567890", "123 main st");	  
	        });
	}
	
	
	@Test
	@DisplayName("Test first name max acceptable length = 10")
	void testMaxAcceptableFirstNameLength() {
		
		Contact contact = new Contact("123456789", "Stephanie.", "Smith", "1234567890", "123 main st");
		assertTrue(contact.getFirstName().length() == 10);
	}
	
	
	@Test
	@DisplayName("Test first name accepts strings < 10")
	void testAcceptsShortFirstNames() {
		
		Contact contact = new Contact("123456789", "Stephanie", "Smith", "1234567890", "123 main st");
		assertTrue(contact.getFirstName().length() < 10);
	}
	
	
	// testing Contact last name requirements
	@Test
	@DisplayName("Test throws exception on null last name")
	void testThrowsExceptionOnNullLast() {
		assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("1234567891", "John", null, "1234567890", "123 main st");	    
	        });
	}
	
	
	@Test
	@DisplayName("Test last name not null")
	void testLastNameNotNull() {
		Contact contact = new Contact("123456789", "John", "Smith", "1234567890", "123 main st");
		assertNotNull(contact.getLastName());
	}
	
	
	@Test
	@DisplayName("Test throws exception on last name too long")
	void testThrowsExceptionOnLastNameTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("1234567891", "John", "Harrington.", "1234567890", "123 main st");	  
	        });
	}
	
	
	@Test
	@DisplayName("Test last name max acceptable length = 10")
	void testMaxAcceptableLastNameLength() {
		
		Contact contact = new Contact("123456789", "John", "Harrington", "1234567890", "123 main st");
		assertTrue(contact.getLastName().length() == 10);
	}
	
	
	@Test
	@DisplayName("Test last name accepts strings < 10")
	void testLastNameAcceptsShortStrings() {
		
		Contact contact = new Contact("123456789", "John", "Hamilton", "1234567890", "123 main st");
		assertTrue(contact.getLastName().length() < 10);
	}
	
	
	// Testing Contact phone requirements
	@Test
	@DisplayName("Test throws exception on null phone")
	void testThrowsExceptionOnNullPhone() {
		assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("1234567891", "John", "Smith", null, "123 main st");	   
	        });
	}
	
	@Test
	@DisplayName("Test phone is not null")
	void testPhoneNotNull() {
		Contact contact = new Contact("123456789", "John", "Hamilton", "1234567890", "123 main st");
		assertNotNull(contact.getPhone());
	}
	
	
	@Test
	@DisplayName("test throws exception on phone too long")
	void testThrowsExceptionOnPhoneTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("1234567891", "John", "Smith", "12345678901", "123 main st");
	        });
	}

	
	@Test
	@DisplayName("test throws exception on phone too short")
	void testThrowsExceptionOnPhoneTooShort() {
		assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("1234567891", "John", "Smith", "123456789", "123 main st");
	        });
	}
	
	
	@Test
	@DisplayName("test phone length must be 10")
	void testPhoneLengthMustBeTen() {
		
		Contact contact = new Contact("123456789", "John", "Smith", "1234567890", "123 main st");
		assertTrue(contact.getPhone().length() == 10);
	}
	
	
	// Testing Contact address requirements
	@Test
	@DisplayName("test throws exception on null address")
	void testThrowsExceptionOnNullAddress() {
		assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("1234567891", "John", "Smith", "1234567890", null);	  
	        });
	}
	
	
	@Test
	@DisplayName("test address is not null")
	void testAddressNotNull() {
		Contact contact = new Contact("123456789", "John", "Smith", "1234567890", "123 main st");
		assertNotNull(contact.getAddress());
	}
	
	
	@Test
	@DisplayName("test throws exception on address too long")
	void testThrowsExceptionOnAddressTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("1234567891", "John", "Smith", "1234567899", "123 main st, New Hampshire 12345");
	        });
	}

	
	@Test
	@DisplayName("test address max acceptable length = 30")
	void testMaxAcceptableAddressLength() {
		
		Contact contact = new Contact("123456789", "John", "Smith", "1234567891", "123 main st, New Hampshire US.");
		assertTrue(contact.getAddress().length() == 30);
	}
	
	
	@Test
	@DisplayName("test address max accepts length < 30")
	void testAddressAcceptsShortStrings() {
		
		Contact contact = new Contact("123456789", "John", "Smith", "1234567891", "123 main st, New Hampshire US");
		assertTrue(contact.getAddress().length() < 30);
	}
}
