package test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import model.Appointment;
import model.Contact;
import model.ContactService;


class ContactServiceTest {
	
	private ContactService contactService;
	private String contactId;
	// [NOTE] the contact ID is inherently not updatable once a contact object is created.
	// [NOTE] the contactList list inherently accepts only contacts with UNIQUE ID.
	
	@BeforeEach
	void addContactsToList() {
		contactService = new ContactService();
		contactService.getContactList().add(new Contact(contactService.createUniqueId(), "first name", "last name", "1234567891", "123 main st"));
		contactService.getContactList().add(new Contact(contactService.createUniqueId(), "first name", "last name", "1234567891", "123 main st"));
		contactService.getContactList().add(new Contact(contactService.createUniqueId(), "first name", "last name", "1234567891", "123 main st"));
		Contact contact = new Contact(contactService.createUniqueId(), "first name", "last name", "1234567891", "123 main st");
		contactService.getContactList().add(contact);
		contactId = contact.getId();
	}
	
	
	@Test
	@DisplayName("Test throws exception when inserting a null object")
	void testAddContactThrowsExceptionOnNullObjectAndLeavesListUnchanged() {
		assertAll(
				() -> assertThrows(IllegalArgumentException.class, () -> {
					contactService.addContact(null);}),
				() -> assertTrue(contactService.getContactList().size() == 4));
	}
	
	
	@Test
	@DisplayName("Test successfully add a contact")
	void testSuccessfulAddContact() {
		contactService.addContact(new Contact(contactService.createUniqueId(), "John", "Smith", "1234567891", "123 main st"));
		assertTrue(!contactService.getContactList().isEmpty());
	}
	
	
	@Test
	@DisplayName("Test throws exception when adding non unique ID")
	void testAddingNonUniqueContactIDThrowsExceptionAndLeavesListUnchanged() {
		
		assertAll (
				() -> assertThrows(IllegalArgumentException.class, () -> {
					contactService.addContact(new Contact(contactId, "John", "Smith", "1234567891", "123 main st"));}),
				() -> assertTrue(contactService.getContactList().size() == 4));
	}
	
	
	// Testing deleting a contact
	@Test
	@DisplayName("Test throws exception when deleting an non existing contact")
	void testDeleteUnexistingContact() {
		assertAll(
				() -> assertThrows(IllegalArgumentException.class, () -> {
					contactService.deleteContact("123456789");}),
				() -> assertTrue(contactService.getContactList().size() == 4));
	}
	
	
	@Test
	@DisplayName("Test successfully removing a contact")
	void successfulRemoveContact() {
		contactService.deleteContact(contactId);
		assertTrue(contactService.getContactList().size() == 3);
	}
	
	
	// Test updating contact fields
	// Update first name
	@Test
	@DisplayName("Test update contact first name")
	void testUpdateContactFirstName() {

		contactService.updateFirst(contactId, "Mary");
		
		assertTrue(contactService.getContactList().get(3).getFirstName().equals("Mary"));
	}

	
	// update last name
	@Test
	@DisplayName("Test update contact last name")
	void testUpdateContactLastName() {
		
		contactService.updateLast(contactId, "Flowers");
		
		assertTrue(contactService.getContactList().get(3).getLastName().equals("Flowers"));
	}
	
	
	// update contact phone
	@Test
	@DisplayName("Test update contact number")
	void testUpdateContactNumber() {
		
		contactService.updatePhone(contactId, "9876543210");
		
		assertTrue(contactService.getContactList().get(3).getPhone().equals("9876543210"));
	}
	
	
	// test update contact address
	@Test
	@DisplayName("Test update contact address")
	void testUpdateContactAddress() {

		contactService.updateAddress(contactId, "124 main st");
		
		assertTrue(contactService.getContactList().get(3).getAddress().equals("124 main st"));
	}
}
