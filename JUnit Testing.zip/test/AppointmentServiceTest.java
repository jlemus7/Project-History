package test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import model.Appointment;
import model.AppointmentService;

class AppointmentServiceTest {
	
	AppointmentService appService = new AppointmentService();
	
	// [NOTE] the appointment ID is inherently not updatable once a appointment object is created.

	// Test adding an object
	@Test
	@DisplayName("Test throws exception when inserting a null object")
	void testAddNullAppointmentThrowsExceptionAndLeavesListUnchanged() {
		assertAll(
				() -> assertThrows(IllegalArgumentException.class, () -> {
					appService.addAppointment(null);}),
				() -> assertTrue(appService.getAppointmentList().isEmpty())); 	// ensures list remains unchanged
	}
	
	
	@Test
	@DisplayName("Test appointrment object not null")
	void testAppointmentNotNullAfterCreation() throws ParseException {
		assertNotNull(new Appointment("123456789", "2023-12-24", "app description here"));
	}
	
	
	@Test
	@DisplayName("Test throws exception on non unique ID")
	void testAddingNonUniqueAppointmentIDThrowsExceptionAndLeavesListUnchanged() throws ParseException {
		appService.addAppointment(new Appointment(appService.createUniqueId(), "2023-12-24", "app description here"));
		appService.addAppointment(new Appointment(appService.createUniqueId(), "2023-11-24", "app description"));
		appService.addAppointment(new Appointment(appService.createUniqueId(), "2023-11-24", "description"));
		Appointment appointment = new Appointment(appService.createUniqueId(), "2023-12-24", "Description here");
		appService.addAppointment(appointment); 
		// list size should be 4 now.
		
		Appointment appointment2 = new Appointment(appointment.getId(), "2023-12-24", "Description here");
		
		assertAll (
				() -> assertThrows(IllegalArgumentException.class, () -> {
					appService.addAppointment(appointment2);}),
				() -> assertTrue(appService.getAppointmentList().size() == 4)); 	// ensures list remains unchanged
		
	}


	@Test
	@DisplayName("Test successfully adding an Appointment")
	void testSuccessfulAppointmentAddition() throws ParseException {
		appService.addAppointment(new Appointment("123456789", "2023-12-24", "app description here"));
		assertTrue(!appService.getAppointmentList().isEmpty());
	}
	
	
	// Test deleting an appointmnt
	@Test
	@DisplayName("Test throws exception when removing non existing appointment")
	void testRemoveNonExistingAppointmentThrowsExceptionAndLeavesListUnchanged() throws ParseException {
		appService.addAppointment(new Appointment(appService.createUniqueId(), "2023-12-24", "description here"));
		
		assertAll (
		() -> assertThrows(IllegalArgumentException.class, () ->  {
			appService.deleteAppointment("123456789");}),
		() -> assertTrue(appService.getAppointmentList().size() == 1)); 	// ensures list remains unchanged
	}
	
	
	@Test
	@DisplayName("Test successfully deleting an appointment")
	void testSuccessfulAppointmentDeletion() throws ParseException {
		Appointment appointment = new Appointment(appService.createUniqueId(), "2023-12-24", "description here");
		appService.addAppointment(appointment);
		assertTrue(!appService.getAppointmentList().isEmpty()); // ensures appointment object is added into list
		
		appService.deleteAppointment(appointment.getId());
		assertTrue(appService.getAppointmentList().isEmpty()); // ensures appointment object is deleted from list
	}
}
