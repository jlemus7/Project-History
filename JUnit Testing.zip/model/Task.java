package model;

public class Task {
	
	private String id;
	private String name;
	private String description;
	
	public Task(String id, String name, String description) {
		
		this.id = validate(id, 1, 10);
		this.name = validate(name, 1, 20);
		this.description = validate(description, 1, 50);
				
	}

	// setters
	public void setName(String name) {
		this.name = validate(name, 1, 20);
	}
	
	public void setDescription(String description) {
		this.description = validate(description, 1, 50);
	}
	
	// getters
	public String getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
		
	public String getDescription() {
		return description;
	}
	
	private String validate(String input, int min, int max) {
		if (input == null) {
			throw new IllegalArgumentException("Invalid input");
		}
		if (input.length() < min || input.length() > max) {
			throw new IllegalArgumentException("Invalid input");
		}
		return input;
	}
	
	

}
