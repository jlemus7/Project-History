package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class TaskService {
	
	private List<Task> taskList = new ArrayList();
	
	public TaskService() {
		// constructor
	}
	
	
	public void updateTaskName(String id, String name) {
		for (Task task: taskList) {
			if (task.getId().equals(id)) {
				task.setName(name);
				return;
			}
		}
		throw new IllegalArgumentException("Invalid id");
	}
	
	public void updateTaskDescription(String id, String description) {
		for (Task task: taskList) {
			if (task.getId().equals(id)) {
				task.setDescription(description);
				return;
			}
		}
		throw new IllegalArgumentException("Invalid id");
	}
	
	public void addTask(Task task) {
		boolean isUnique = true;
		
		if (task == null) {
			throw new IllegalArgumentException("null task object");
		}
		
		// validates id uniqueness before adding it to the list
		for (Task t : taskList) {
			if (t.getId().equals(task.getId())) {
				isUnique = false;
				throw new IllegalArgumentException("Invalid id");
			}
		}
		
		if (isUnique) {
			taskList.add(task);
		}
	}
	
	public void deleteTask(String id) {
		for (Task task : taskList) {
			if (task.getId().equals(id)) {
				taskList.remove(task);
				return;
			}
		}
		throw new IllegalArgumentException("ID does not exist");
	}
	
	public List<Task> getTaskList() {
		return taskList;
	}
	
	
	// Creates unique Id for random numbers.
	public String createUniqueId() {
				
		String id = null;
			
		Random random = new Random();
		int random1 = random.nextInt(90000) + 10000;
		int random2 = random.nextInt(90000) + 10000;
				
		id = Integer.toString(random1) + Integer.toString(random2);

		return id;
	}
}
