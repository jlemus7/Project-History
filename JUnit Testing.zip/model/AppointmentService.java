package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class AppointmentService {
	
	private List<Appointment> appointmentList = new ArrayList();
	
	public AppointmentService() {
		// constructor
	}
	
	public void addAppointment(Appointment appointment) {
		
		boolean isUnique = true;
		
		if (appointment == null) {
			throw new IllegalArgumentException("appointment object is null");
		}
		
		for (Appointment a : appointmentList) {
			if (a.getId().equals(appointment.getId())) {
				isUnique = false;
				// throws exception if Id is not unique.
				throw new IllegalArgumentException("ID is not unique");
			}
		}
		
		if (isUnique) {
			appointmentList.add(appointment);
		}
	}
	
	
	public void deleteAppointment(String id) {
		
		for (Appointment appointment : appointmentList) {
			if (appointment.getId().equals(id)) {
				appointmentList.remove(appointment);
				return;
			}
		}
		// throws exception if appointment does not exist.
		throw new IllegalArgumentException("Appointment does not exist");
	}

	
	// Creates unique Id for random numbers.
		public String createUniqueId() {
					
			String id = null;
				
			Random random = new Random();
			int random1 = random.nextInt(90000) + 10000;
			int random2 = random.nextInt(90000) + 10000;
					
			id = Integer.toString(random1) + Integer.toString(random2);

			return id;
		}
		
		public List<Appointment> getAppointmentList() {
			return appointmentList;
		}
}
