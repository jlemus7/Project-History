package model;

import java.util.List;
import java.util.Random;
import java.util.ArrayList;


public class ContactService {
	
	private List<Contact> contactList = new ArrayList();
	
	public ContactService() {
		// constructor
	}
	
	
	public void addContact(Contact contact) {
		boolean isUnique = true;
		
		if (contact == null) {
			throw new IllegalArgumentException("contact object is null");
		}
		
		for (Contact c: contactList) {
			if (c.getId().equals(contact.getId())) {
				isUnique = false;
				throw new IllegalArgumentException("Invalid id");
			}	
		}
		
		if (isUnique) {
			contactList.add(contact);
		}
	}
	
	public void deleteContact(String id) {
		
		for (Contact contact: contactList) {
			if (contact.getId() == id) {
				contactList.remove(contact);
				return;
			}
		}
		
		if (true) {
			throw new IllegalArgumentException("Contact does not exists");
		}
	}
	
	public void updateFirst(String id, String name) {
		for(Contact contactItem: contactList) {
			if (contactItem.getId() == id) {
				contactItem.setFirstName(name);
				return;
			}
		}
	}
	
	public void updateLast(String id, String last) {
		for(Contact contactItem: contactList) {
			if (contactItem.getId() == id) {
				contactItem.setLastName(last);
				return;
			}
		}
	}
	
	public void updatePhone(String id, String phone) {
		for(Contact contactItem: contactList) {
			if (contactItem.getId() == id) {
				contactItem.setPhone(phone);
				return;
			}
		}
	}
	
	public void updateAddress(String id, String address) {
		for(Contact contactItem: contactList) {
			if (contactItem.getId() == id) {
				contactItem.setAddress(address);
				return;
			}
		}
	}
	
	public List<Contact> getContactList() {
		return contactList;
	}
	
	
	// Creates unique Id for random numbers.
		public String createUniqueId() {
					
			String id = null;
				
			Random random = new Random();
			int random1 = random.nextInt(90000) + 10000;
			int random2 = random.nextInt(90000) + 10000;
					
			id = Integer.toString(random1) + Integer.toString(random2);

			return id;
		}

}
