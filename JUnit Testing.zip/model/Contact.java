package model;

public class Contact {
	
	// declaration of arguments
	private String id;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;

	// Constructor
	public Contact (String id, String firstName, String lastName, String phone, String address) {
	
		
		this.id = validate(id, 1, 10);
		this.firstName = validate(firstName, 1, 10);
		this.lastName = validate(lastName, 1, 10);
		this.phone = validatePhone(phone);
		this.address = validate(address, 1, 30);
	}

	// setters
	public void setFirstName(String firstName) {
		this.firstName = validate(firstName, 1, 10);
	}
	
	public void setLastName(String lastName) {
		this.lastName = validate(lastName, 1, 10);
	}
	
	public void setPhone(String phone) {
		this.phone = validatePhone(phone);
	}
	
	public void setAddress(String address) {
		this.address = validate(address, 1, 30);
	}
	
	
	// getters
	public String getId() {
		return id;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public String getPhone() {
		return phone;
	}
	
	public String getAddress() {
		return address;
	}
	
	private String validate(String input, int min, int max) {
		if (input == null) {
			throw new IllegalArgumentException("Invalid input");
		}
		if (input.length() < min || input.length() > max) {
			throw new IllegalArgumentException("Invalid input");
		}
		return input;
	}
	
	private String validatePhone(String input) {
		if (input == null) {
			throw new IllegalArgumentException("Invalid phone");
			
		}
		if (input.length() != 10) {
			throw new IllegalArgumentException("Invalid phone");
		}
		
		return input;
	}
	
}
