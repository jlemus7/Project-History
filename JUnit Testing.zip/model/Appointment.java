package model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Appointment {
	
	private String id;
	private String date;
	private String description;
	
	public Appointment(String id, String date, String description) throws ParseException {
		
		this.id = validate(id, 1, 10);
		this.date = validDate(date);
		this.description = validate(description, 1, 50);
	}
	
	
	// getters
	public String getId() {
		return id;
	}
	
	public String getDate() {
		return date;
	}
	
	public String getDescription() {
		return description;
	}
	
	private String validate(String input, int min, int max) {
		if (input == null) {
			throw new IllegalArgumentException("Invalid input");
		}
		if (input.length() < min || input.length() > max) {
			throw new IllegalArgumentException("Invalid input");
		}
		return input;
	}
	
	
	private String validDate(String date) throws ParseException {
		
		Date inputDate = null;
		
		// check for null input
		if (date == null) {
			throw new IllegalArgumentException("Invalid date");
		} 
		else if (date.length() != 10) {
			// validate length
			throw new IllegalArgumentException("Invalid date");
		}
		else if (date.charAt(4) != '-' && date.charAt(7) != '-') {
			// validate date format. Expected format yyyy-MM-dd
			throw new IllegalArgumentException("Invalid date format");
		}
		
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		
		try {
			inputDate = dateFormat.parse(date);
		} catch (ParseException e) {
			throw e;
		} 
		if (inputDate.before(new Date())) {
			throw new IllegalArgumentException("Date is in the past");
		}
		// date is valid
		return date;
	}

}
