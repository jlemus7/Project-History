from pymongo import MongoClient
from bson.objectid import ObjectId
import pprint

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        USER = username     #aacuser
        PASS = password     #SNHU1pass
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31532
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        try: 
            self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER, PASS, HOST, PORT))
            self.database = self.client['%s' % (DB)]
            self.collection = self.database['%s' % (COL)]
            print('Conneted to database')
     
        except Exception as e:
            print(f'Error connecting to MongoDB...\n{e}')

    # Complete this create method to implement the C in CRUD.
    def create(self, data) -> bool:
        if data is not None:
            self.database.animals.insert_one(data)  # data should be dictionary
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            return False

        return True

    # Create method to implement the R in CRUD.
    def read(self, query) -> list:
  
        if len(query) == 0:
            # returns a set of documents. No specific document was required
            cursor = self.database.animals.find()
            return list(cursor)
        else:
            # a specific document is being searched
            try:
                print(f'searching for data: {query}.')
                cursor = self.database.animals.find(query)
                return list(cursor)
            except Exception as e:
                print(f'An error occurred while reading the data.\n{e}')
                
                
    # Update method to update documents in MongoDB
    # update() allows users to find a document by using any key/value pair to
    # update any key/value pair within the document.
    def update(self, query, data) -> int:
        uniqueIdentifiers = ['_id', 'animal_id']
        updatedDocs = 0
        
        if uniqueIdentifiers[0] in query or uniqueIdentifiers[1] in query:
            # uses unique identifier to update a single document.
            try:
                result = self.database.animals.update_one(query, {'$set': data})
                updatedDocs = result.modified_count
                
            except Exception as e:
                print(f'Error updating data {query}...\n{e}')
                
        else:
            # key/value are not unique identifiers. Updates many documents in the database
            try:
                result = self.database.animals.update_many(query, {'$set': data})
                updatedDocs = result.modified_count
                
            except Exception as e:
                print(f'Error updating data {query}...\n{e}')
                
        return updatedDocs
            
    # Delete a document from the database. Uses a query to delete ONE document on the database.
    def delete(self, query) -> int:
        
        deletedDocs = 0
        
        try:
            # tries removing the document from the database
            result = self.database.animals.delete_one(query)
            deletedDocs = result.deleted_count
                
        except Exception as e:
            print(f'Error deleting data {query}...\n{e}')
                
        return deletedDocs
        
    
    # Single call to index the data in the database
    def indexDatabase(self) -> bool:
        # use breed as the first index since multiple entries do not have a name
        try:
            collection = self.database.animals
            query = [("breed", 1), ("name", 1), ("animal_id", 1)]
            print(query)
            collection.create_index(query)
            return True
        except Exception as e:
            print(f'Error indexing data...\n{e}')
            return False
        
    # authenticate user credentials
    def authenticate(self) -> bool:
        
        if self.USER =='aacuser' and self.PASS =='SNHU1pass':
            return True
        else:
            return False