import java.util.ArrayList;
import java.util.Scanner;


public class Driver {
    private static ArrayList<Dog> dogList = new ArrayList<Dog>();
    private static ArrayList<Monkey> monkeyList = new ArrayList<Monkey>();
    private static String[] trainingLevels = {"farm", "intake", "Phase I", "Phase II", "Plase III", "Phase IV", "Phase V", "in service"};
    private static String[] reservationStatus = {"yes", "no"};

    public static void main(String[] args) throws Exception {
    	Scanner scnr = new Scanner(System.in);

        initializeDogList();
        initializeMonkeyList();
        String userInput = "0";

		while (!userInput.equals("q")) {
			displayMenu();
			userInput = scnr.nextLine();
			try {
				
				switch (userInput) {
				case "1":
					// intakes a new dog
					intakeNewDog(scnr);
					break;
				case "2":
					// intakes a new monkey
					intakeNewMonkey(scnr);
					break;
				case "3":
					// checks for reserved animals
					reserveAnimal(scnr);
					break;
				case "4":
					// print all dogs
					printAnimals(4);
					break;
				case "5":
					// print all monkeys;
					printAnimals(5);
					break;
				case "6":
					// print all animals not reserved
					printAnimals(6);
					break;
				default:
					if (userInput.equals("q")) {
						// closes program
						System.out.println("Closing program...");
					} else {
						// handles every other type of input
						throw new Exception("Invalid Input!");
					}
				}
			}catch (Exception e) {
				System.out.println(e.getMessage());	
			}
		}
    }

    
    // This method prints the menu options
    public static void displayMenu() {
        System.out.println("\n\n");
        System.out.println("\t\t\t\tRescue Animal System Menu");
        System.out.println("[1] Intake a new dog");
        System.out.println("[2] Intake a new monkey");
        System.out.println("[3] Reserve an animal");
        System.out.println("[4] Print a list of all dogs");
        System.out.println("[5] Print a list of all monkeys");
        System.out.println("[6] Print a list of all animals that are not reserved");
        System.out.println("[q] Quit application");
        System.out.println();
        System.out.println("Enter a menu selection");
    }

    
    // Adds dogs to a list for testing
    public static void initializeDogList() {
        Dog dog1 = new Dog("Spot", "German Shepherd", "male", "1", "25.6", "05-12-2019", "United States", "intake", false, "United States");
        Dog dog2 = new Dog("Rex", "Great Dane", "male", "3", "35.2", "02-03-2020", "United States", "Phase I", false, "United States");
        Dog dog3 = new Dog("Bella", "Chihuahua", "female", "4", "25.6", "12-12-2019", "Canada", "in service", true, "Canada");

        dogList.add(dog1);
        dogList.add(dog2);
        dogList.add(dog3);
    }


    // Adds monkeys to a list for testing
    public static void initializeMonkeyList() {
    	Monkey monkey1 = new Monkey("Abu", "Golden snub-nosed", "female", "2", "40.5", "30", "40.7", "20.5", "10-05-2020", "United States", "Phase II", false,"United States");
    	Monkey monkey2 = new Monkey("Boots", "Vervet", "male", "4", "25.6", "36.4", "50.6", "40.4", "12-05-2018", "United States", "in service", true,"Canada");
    	Monkey monkey3 = new Monkey("George", "Tamarin", "male", "4", "35.4", "50.3", "55.9", "15.8", "04-09-2020", "Canada", "in service", false, "not availale");
    	
    	monkeyList.add(monkey1);
    	monkeyList.add(monkey2);
    	monkeyList.add(monkey3);
    }


    // Intakes new dogs
    public static void intakeNewDog(Scanner scanner) throws Exception {
   	 	String serviceCountry;
   	 	boolean reserved = false;
   	 	String reservation;
   	 	
   	 	// Input validation to check that the dog is not already in the list
   	 	String name = stringValidation(scanner, "What is the dog's name?");
   	 	for(Dog dog: dogList) {
   	 		if(dog.getName().equalsIgnoreCase(name)) {
            System.out.println("\n\nThis dog is already in our system\n\n");
               
            return; //returns to menu
   	 		}  	
   	 	}
       // instantiate a new dog and add it to the appropriate list
       String breed = stringValidation(scanner,"What is the dog's breed?" );
       String gender = stringValidation(scanner,"What is the dog's gender?");
       String age = doubleValidation(scanner, "What is the dog's age?");
       String weight = doubleValidation(scanner, "What is the dog's weight?");
       String date = dateValidation(scanner);
       String aquisitionCountry = stringValidation(scanner,"What is the dog's country of aquisition?");
       String trainingStatus = inputValidation(scanner, trainingLevels, "What is the dog's training level?", "Invalid training level");
       // takes country of service and reservation status only if dog is in-service
       if (trainingStatus.equals("in service")) {
           serviceCountry = stringValidation(scanner,"Where is the dog serving?");
           reservation = inputValidation(scanner, reservationStatus, "Is the dog reserved: (yes / no)?", "Invalid reservation status");
           if (reservation.equals("yes")) {
           	reserved = true;
           } else if (reservation.equals("no")) {
           	reserved = false;
           }
       } else {
       	serviceCountry = "not available";
       	// reserved status cannot be changed because training is incomplete
       	reserved = true;
       }
   
       // Instantiate new dog
       Dog newDog = new Dog(name, breed, gender, age, weight, date, aquisitionCountry, trainingStatus, reserved, serviceCountry);
       // Adds new dog to dogList
       dogList.add(newDog);
       System.out.println(name + " has been added to the list\n");
       
       return;	// returns to menu
   }
    
    
	// to make sure the monkey doesn't already exist and the species type is allowed
    public static void intakeNewMonkey(Scanner scanner) throws Exception{
    	String[] monkeyTypes = {"Capuchin", "Guenon", "Macaque", "Marmoset", "Squirrel monkey", "Tamarin"};
    	String serviceCountry;
    	boolean reserved = false;
    	String species = " ";
    	String reservation;
    	
    	String name = stringValidation(scanner, "What is the monkey's name?");
    	// The input validation to check that the monkey is not already in the list
        for(Monkey monkey: monkeyList) {
            if(monkey.getName().equalsIgnoreCase(name)) {
                System.out.println("\n\nThis monkey is already in our system\n\n");
                return; //returns to menu
            }
        }         
        // instantiate a new monkey and add it to the appropriate list
        species = inputValidation(scanner, monkeyTypes, "What is the monkey's species?", "Invalid species!");
        String gender = stringValidation(scanner, "What is the monkey's gender?");
        String age = doubleValidation(scanner, "What is the monkey's age?");
        String weight = doubleValidation(scanner, "What is the monkey's weight?");
        String heigth = doubleValidation(scanner, "What is the monkey's height?");
        String bodyLength = doubleValidation(scanner, "What is the monkey's body length?");
        String tailLength = doubleValidation(scanner, "What is the monkey's tail length?");
        String aquisitionDate = dateValidation(scanner);
        String aquisitionLocation = stringValidation(scanner, "What is the monkey's aquisition location?");
        String trainingStatus = inputValidation(scanner, trainingLevels, "What is the monkey's training level?", "Invalid training level");
        // takes country of service and reservation status only if monkey is in-service
        if (trainingStatus.equals("in service")) {
        	serviceCountry = stringValidation(scanner,"What is the monkey's country of service?");
        	reservation = inputValidation(scanner, reservationStatus, "Is the monkey reserved: (yes / no)?", "Invalid reservation status");
            if (reservation.equals("yes")) {
            	reserved = true;
            } else if (reservation.equals("no")) {
            	reserved = false;
            }
        } else {
        	serviceCountry = "not available";
        	// reserved status cannot be changed because training is incomplete
        	reserved = true;
        }
        
        // Instantiate new monkey
        Monkey newMonkey = new Monkey(name, species, gender, age, weight, heigth, bodyLength,
    		tailLength, aquisitionDate, aquisitionLocation, trainingStatus, reserved, serviceCountry);
        // adds new monkey to monkeyList
        monkeyList.add(newMonkey);
        System.out.println(name + " has been added to the list\n");
        
        return;
        }

    
        // Change reservation status of an animal based on the type and country of service
        public static void reserveAnimal(Scanner scanner) throws Exception {

            String[] animal = {"dog", "monkey"};
        	String country;
        	String animalType;
        	boolean status;
        	
        	// prompt user for valid animal type and country.
        	animalType = inputValidation(scanner, animal, "Enter animal type (dog / monkey)", "Invalid animal type!");
        	String prompt = "What is the " + animalType + "'s country of service?";
        	country = stringValidation(scanner, prompt);
        	
        	if (animalType.equals(animal[0])) {
        		for (Dog dog : dogList) {
        			if (country.equals(dog.getInServiceLocation())) {
        				// updates reservation status if animal found on list
        				System.out.println("Name: " + dog.getName() + "\nCountry of service: " + 
        						dog.getInServiceLocation() + "\nReservation status: " + dog.getReserved());
        				System.out.println("Enter new status (true / false)");
        				status = scanner.nextBoolean();
        				scanner.nextLine();
        				dog.setReserved(status);
        				System.out.println(dog.getName() + "'s reservation status has been updated.");
        				return;
        			} 
        		}
        	} else if (animalType.equals(animal[1])) {
        		for (Monkey monkey : monkeyList) {
        			if (country.equals(monkey.getInServiceLocation())) {
        				// updates reservation status if animal found on list
        				System.out.println("Name: " + monkey.getName() + "\nCountry of service: " + 
        						monkey.getInServiceLocation() + "\nReservation status: " + monkey.getReserved());
        				System.out.println("Enter new status (true / false)");
        				status = scanner.nextBoolean();
        				scanner.nextLine();
        				monkey.setReserved(status);
        				System.out.println(monkey.getName() + "'s reservation status has been updated.");
        				return;
        			}
        		}
        	}
        	// informs the user if no animal was found
        	System.out.println("No " + animalType + " was not found.");

        	return;
        }

        
        // Prints animals of the list dogList and monkeyList
        public static void printAnimals(int menu) {
        	String animalDetails;
            
        	for (Dog dog : dogList) {
        		animalDetails = "  Name: " + dog.getName() + "\n  Training status: " + dog.getTrainingStatus() +
        				"\n  Aquisition country: " + dog.getAcquisitionLocation() + "\n  Reserved: " + dog.getReserved();
        		// prints all the dogs
        		if (menu == 4) {
        			System.out.println(animalDetails);
        		} else if (menu == 6) {
        			// prints available dogs
        			if (dog.getTrainingStatus().equals("in service") && dog.getReserved() == false) {
        				System.out.println(animalDetails);
        			}
        		}
        		System.out.println();
        	}
        	
        	for (Monkey monkey : monkeyList) {
        		animalDetails = "  Name: " + monkey.getName() + "\n  Training status: " + monkey.getTrainingStatus() +
        				"\n  Aquisition country: " + monkey.getAcquisitionLocation() + "\n  Reserved: " + monkey.getReserved();
        		// prints all the monkeys
        		if (menu == 5) {
        			System.out.println(animalDetails);
        		} else if (menu == 6) {
        			// prints available monkeys
        			if (monkey.getTrainingStatus().equals("in service") && monkey.getReserved() == false) {
        				System.out.println(animalDetails);
        			}
        		}
        		System.out.println();
        	}
    	}
        
        
     // input validation for strings
        public static String stringValidation(Scanner sc, String prompt) throws Exception {
    		// Reads scanner for a string that only contains alphabetic characters.
        	// Throws exception if input has numbers or other characters.
    		String userInput = "";
    		boolean needInput = true;
    		
    		while (needInput) {
    			System.out.println(prompt);
    			try {
    				if (sc.hasNext("[A-Za-z]*")) {
    					needInput = false;
    					userInput = sc.nextLine();
    					break;
    				} else {
    					needInput = true;
    					throw new Exception("Invalid input!");
    				}		
    			} catch (Exception ex) {
    				System.out.println(ex.getMessage());
    			}
    		userInput = sc.nextLine();
    		}
    		return userInput;
    	}
        
        
     // input validation for double type
        public static String doubleValidation(Scanner scanner, String prompt) throws Exception {
    		// Reads scanner for numbers (doubles and integers) and convert them into strings.
        	// throws exception if input has word characters.
    		String userInput = "";
    		boolean needInput = true;
    		
    		while (needInput) {
    			System.out.println(prompt);
    			try {
    				if (scanner.hasNextDouble()) {
    					needInput = false;
    					userInput = scanner.nextLine();
    					break;
    				} else {
    					needInput = true;
    					throw new Exception("Invalid input!");
    				}		
    			} catch (Exception ex) {
    				System.out.println(ex.getMessage());
    			}
    		userInput = scanner.nextLine();
    		}
    		return userInput;
    	}
        
        
        // input validation for array items
        public static String inputValidation(Scanner scanner, String[] array, String prompt, String message) throws Exception {
        	// validates user input and compares it to values of a selected array.
        	boolean needInput = true;
        	String validString = " ";
        	
        	while (needInput) {
            	validString = stringValidation(scanner, prompt);
    			for (String token: array) {
    				if (validString.equals(token)) {
    					needInput = false;
    					break;
    				} else {
    					needInput = true;
    				}
    			}
    			if(needInput == true) {
    				System.out.println(message);
    			}
        	}
        	return validString;
        }
        
        
        // date format validation
        public static String dateValidation(Scanner scnr) {
    		boolean needInput = true;
    		String input = "";
    		
    		while (needInput) {
    			System.out.println("What is the aquisition date (mm-dd-yyyy)?");
    			input = scnr.nextLine();
    			
    			try {
    				// checks input for correct length and format
    				if (input.charAt(2) != '-' || input.charAt(5) != '-' || input.length() > 10 || input.length() < 9) {
    					needInput = true;
    					throw new Exception("Invalid date format");
    				} else {
    					needInput = false;
    					return input;
    				}
    			} catch (Exception e) {
    				System.out.println(e.getMessage());	
    			} 
    		}
    		return input;
    	}        
}
