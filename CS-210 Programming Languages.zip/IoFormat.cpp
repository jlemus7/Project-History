
#include <algorithm>
#include <fstream>
#include "IoFormat.h"
#include "CornerGrocer.h"

using namespace cgs;
namespace iof {

	void IoFormat::GetInteger(const string& prompt, const int& minVal, const int& maxVal, int& value) {
		/*
		* GetInteger() takes a three values as parameters passed by refference, a prompt for the user, a minimum value, an maximum value
		* and a value to evaluate. The function uses a while loop to prompt the user for a value and uses try/catch
		* mechanism to handle input mismatch. If the Input datatype is different, the program will throw an exception
		* informing the user of the problem, else, if the user enters a value out of range, another exception is thrown
		* that catches that specific type of error. The loop is exited if and only if a valid input is entered.
		*/ 
		bool needInput = true;

		while (needInput) {
			cout << prompt;
			try {
				cin >> value;
				if (cin.fail()) {
					throw runtime_error("Invalid input...");
				}
				else if (value < minVal || value > maxVal) {
					throw runtime_error("Input out of range...");
				}
				else {
					// Input is correct, breaks loop.
					needInput = false;
				}
			}
			catch (ios::failure& excpt) {
				cout << excpt.what() << endl;
			}
			catch (runtime_error& expt) {
				cout << expt.what() << endl;
			}
			// Clears the buffer.
			cin.clear();
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
		}
	}


	void IoFormat::GetString(const string& prompt, string& input, vector<string>& validItems) {
		/*
		* GetString() validates input strings. The function takes three values as patameters passed by refference, a string
		* to prompt the user for a value, a string variable to store the user's input, and a vector used to validate the input.
		* A while loop prompts the user for a value, the value is the transformed to Title format in order to compare it against
		* the items on the vector. If the input is not equal to any item of the vector, an exception is thrown informing the user
		* that such item is not on the list. The user will be prompted for an input until a correct input is entered.
		*/
		bool needInput = true;
		while (needInput) {
			cout << prompt;
			try {
				cin >> input;
				input = ToTitle(input);
				if (!count(validItems.begin(), validItems.end(), input)) {
					// Throws exception if item not found on vector list.
					throw runtime_error("Item not found...");
				}
				else {
					// Input is correct, breaks the loop.
					needInput = false;					
				}
			}
			catch (runtime_error& excpt) {
				cout << excpt.what() << endl;
			}
			// clears the buffer.
			cin.clear();
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
		}
	}


	void IoFormat::ReadFile(const string& fileName, vector<string>& items) {
		/*
		* ReadFile() reads a text file by creating an input stream.
		* The stream opens the file of name fileName, if the file is open correctly,
		* the programs reads all the data from the file word-by-word until the end is reached, else,
		* the program will inform the user that could not open the file.
		* If a problem is found before the end is reached, the program will inform the user and exit the loop.
		* The input will be added into a vector to be processed elsewhere.
		*/
		ifstream tempsSF;
		string itemName;

		tempsSF.open(fileName);			// Open file

		if (tempsSF.is_open()) {		// Continues only if the file has been open correctly.

			while (!tempsSF.eof()) {	// Reads file until the end is reached.

				// Reads data from file and inserts it into variables.
				tempsSF >> itemName;

				items.push_back(itemName);				// Inserts city name into vector.

				if (tempsSF.fail()) {
					// Informs the user if an error has occured while reading the file.
					cout << "Error found while reading data. . ." << endl;
					break;
				}
			}
			// Informs the user that the file has been read successfully and closes the file.
			tempsSF.close();
		}
		else {
			// Informs the user if the file cannot be open
			cout << "Could not find data . ." << endl;
		}
	}


	void IoFormat::WriteToFile(const string& fileName, map<string, int> groceryItems) {
		/*
		* WriteToFile() writes output into a file by creating an outpout stream.
		* The stream creates and opens a file of name fileName. If the file is open correctly,
		* the stream reads the data from a map, which is then inserted
		* into the file; else if the file cannot be open, the program informs the user.
		*/
		ofstream outFS;

		outFS.open(fileName);			// create output stream.

		if (outFS.is_open()) {			// Writes into the file only if file has been open correctly.

			for (pair<string, int> item : groceryItems) {
				// Reads information from vectors and outputs it to the file.
				outFS << item.first + " ";
				outFS << item.second << endl;
			}

			outFS.close();
		}
		else {
			// Informs the user if the file cannot be opened.
			cout << "An error has occurred while backing up the data..." << endl;
		}
	}


	string IoFormat::ToTitle(const string input) {
		/*
		* ToTitle() transforms a string to title format. The function creates an empty string and
		* then uses the function from the standard library toupper() to convert the first character
		* to uppercase and then inserts it into the empty string. A for-loop converts the rest of
		* the characters to lowercase starting from index 1 to the end and inserts them into the new
		* string.
		*/
		string updatedInput;
		updatedInput.push_back(toupper(input.at(0)));

		for (int i = 1; i < input.size(); ++i) {
			updatedInput.push_back(tolower(input.at(i)));
		}

		return updatedInput;
	}


	bool SortByValue(const pair<string, int>& firstVal, const pair<string, int>& secondVal) {
		/*
		* SortByValue sorts items of a vector by values on descending order. The function takes two pairs
		* and return the greater value before the second value so it is sorted in descending order.
		*/
		return (firstVal.second > secondVal.second);
	}


	void SortVector(map<string, int>& groceryItems, vector<pair<string, int>>& sortedItems) {
		/*
		* SortVector() inserts pairs of items into a vector that is then is sorted by values.
		* The function uses the sort() function from the standard library, with the SortByValue()
		* function as conditional parameter.
		*/
		map<string, int>::iterator i;
		for (i = groceryItems.begin(); i != groceryItems.end(); ++i) {
			sortedItems.push_back(make_pair(i->first, i->second));
		}
		sort(sortedItems.begin(), sortedItems.end(), SortByValue);
	}


	void IoFormat::MainDriver(vector<string>& validItems, vector<pair<string, int >>& sortedItems, map<string, int>& itemFrequency) {
		/*
		* MainDriver() Drives the menu options of the program. A while-loop displays the menu loop, and runs the menu until the user decides
		* to close the program. The loop gets an input from the user to display the desired items. Within the while-loop is a switch statement
		* that handles the input entered from the user. If the user enters 1, then it will be prompted for an item name. If the user enters 2,
		* the list of all items will be displayed with their respective frequency value. If the user enters 3, then the list of all items will be
		* displayed with their respetive frequency expressed as a histogram. If the user enters 4 then the program will be terminated.
		*/

		CornerGrocer cornerGrocer;
		IoFormat ioFormat;

		string itemName;
		int menuOption;
		bool keepGoing = true;

		while (keepGoing) {
			cornerGrocer.DisplayMenu();		// Disdplays menu to console.

			ioFormat.GetInteger("Enter option: ", 1, 4, menuOption);
			switch (menuOption)			// Displays items based on menu option.
			{
			case 1:
				ioFormat.GetString("Enter item name: ", itemName, validItems);
				cornerGrocer.DisplayItem(itemName, itemFrequency);
				break;

			case 2:
				cornerGrocer.DisplaySortedValues(sortedItems, 2);
				break;

			case 3:
				cornerGrocer.DisplaySortedValues(sortedItems, 3);
				break;

			default:
				// Case 4 is entered.
				cout << "\nClosing program..." << endl;
				keepGoing = false;
				break;
			}
		}
	}
}
