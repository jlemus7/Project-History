
#include <iomanip>
#include "CornerGrocer.h"

namespace cgs {

	void CornerGrocer::DisplayMenu() {
		// Display the menu options to console.
		cout << setfill(' ') << setw(20) << right << "MENU" << endl;
		cout << " 1: Search Frequency of Specific Item." << endl;
		cout << " 2: Display Frequency in Numbers." << endl;
		cout << " 3: Display Frequency in Special Characters." << endl;
		cout << " 4: Exit" << endl;

	}

	void CornerGrocer::DisplayTitle() {
		// Displays the title to console.
		cout << setw(5) << "" << setfill('-') << setw(26) << "" << endl;
		cout << setw(5) << setfill(' ') << "" << "|" << setw(19) << "ITEM FREQUENCY" << setw(6) << "|" << endl;
		cout << setw(5) << "" << setfill('-') << setw(26) << "" << endl << endl;
	}

	vector<string> CornerGrocer::WordFrequency(vector<string> groceryItems, map<string, int>& itemFrequency) {
		/*
		* WordFrequency() Inserts unique items into a vector, counts the number of times such item is repeated
		* and inserts a pair of item and value into a map. The function uses two for-loops, one that evaluates
		* the unique items and inserts them into a vector, the second one uses nested loops to count how many
		* appearances of an item exist on a vector. After the frequency is counted, the pair is inserted into
		* a map. The function also returns the vector of unique items that will be used to evaluate the user's input.
		*/

		vector<string> items;
		int counter = 0;
		items.push_back(groceryItems.at(0));

		for (auto item : groceryItems) {
			// inserts unique items into a vector.
			if (!count(items.begin(), items.end(), item)) {
				items.push_back(item);
			}
		}

		for (auto item : items) {
			// Counts item frequency
			for (auto veggie : groceryItems) {
				if (veggie == item) {
					++counter;
				}
			}
			// Creates pair and inserts it into a map.
			itemFrequency.insert_or_assign(item, counter);
			counter = 0;	// Resets the counter to 0.
		}
		return items;
	}

	void CornerGrocer::DisplayItem(const string& item, map<string, int> groceryItems) {
		/*
		* DisplayItem() outputs a selected item into the console. The function takes an item name
		* and a map as parameters passed by refference. A for-loop searches the specific item in the
		* keys of the map and displays it to the console along with its value.
		*/
		cout << endl << endl;
		for (pair<string, int> groceryItem : groceryItems) {
			if (item == groceryItem.first) {
				cout << setw(25) << setfill('=') << "" << endl;
				cout << setw(15) << setfill(' ') << left << "ITEM NAME" << setw(5) << "FREQUENCY" << endl;
				cout << setw(25) << setfill('-') << "" << endl;
				cout << setw(15) << setfill(' ') << left << groceryItem.first << setw(5) << groceryItem.second << endl;
				cout << setw(25) << setfill('=') << "" << endl;
			}
		}
		cout << endl << endl;
	}

	void CornerGrocer::DisplaySortedValues(vector<pair<string, int>>& sortedItems, int displayType) {
		/*
		* DisplaySortedValues() outputs the keys and values of a map that have been stored into a vector and sorted
		* indecreasing order. The function takes two patameters, a vector passed by refference, and an integer that
		* will decide the way the items are displayed. The displayType variable can either be 2 or 3. if the value is
		* 2, the function will display the items on the vector by key and numerical value. If the value of the parameter
		* is 3, a for-loop will extract every key and display it. A nested for-loop will print a special character for
		* every time the item appears on the original list.
		*/

		cout << endl << endl;
		cout << setw(28) << setfill('=') << "" << endl;
		cout << setw(15) << setfill(' ') << left << "ITEM NAME" << setw(5) << "FREQUENCY" << endl;		// Displays header.
		cout << setw(28) << setfill('-') << "" << endl;
		if (displayType == 2) {
			for (int i = 0; i < sortedItems.size(); ++i) {
				// Prints all the keys and values
				cout << setw(15) << setw(15) << setfill(' ') << left << sortedItems[i].first << setw(12) << sortedItems[i].second << endl;
			}
		}
		else {
			// displayType = 3;
			for (int i = 0; i < sortedItems.size(); ++i) {
				cout << setw(15) << setfill(' ') << left << sortedItems[i].first;		// Prints keys

				for (int j = 0; j < sortedItems[i].second; ++j) {
					setw(12);
					cout << "*";		// Prints frequency.
				}
				cout << endl;
			}
		}
		cout << setw(28) << setfill('=') << "" << endl;
		cout << endl << endl;
	}

	

}