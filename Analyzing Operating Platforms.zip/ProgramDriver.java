package com.gamingroom;

import java.util.List;
import java.util.Scanner;
/**
 * Application start-up program
 * 
 * @author coce@snhu.edu
 */
public class ProgramDriver {
	
	/**
	 * The one-and-only main() method
	 * 
	 * @param args command line arguments
	 */
	public static void main(String[] args) {
		
		// obtain reference to the singleton instance
		GameService service = GameService.getInstance(); 
		
		System.out.println("\nAbout to test initializing game data...");
		
		
		// initialize with some game data
				Game game1 = service.addGame("Game #1");
				System.out.println(game1);
				Game game2 = service.addGame("Game #2");
				System.out.println(game2);
				
				// Test
				 // add some teams to the first game
				 System.out.println("Tests");
			    Team team1 = game1.addTeam("Team A");
			    Team team2 = game1.addTeam("Team B");
			    Team team3 = game1.addTeam("Team C");
			    
			    // add some players to the teams
			    Player player1 = team1.addPlayer("John Doe");
			    Player player2 = team1.addPlayer("Jane Smith");
			    Player player3 = team2.addPlayer("Bob Johnson");
			    Player player4 = team3.addPlayer("Alice Brown");
			    
			    // add a team with a name that already exists
			    Team team4 = game1.addTeam("Team A");
			    
			    // attempt to add a player with a name that already exists
			    Player player5 = team2.addPlayer("John Doe");
			    
			    // output the game data to ensure everything was added correctly
			    System.out.println(game1);
			    System.out.println(game2);
		
		
		// use another class to prove there is only one instance
		SingletonTester tester = new SingletonTester();
		tester.testSingleton();
	}
}