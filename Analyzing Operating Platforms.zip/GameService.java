package com.gamingroom;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 */
public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	/*
	 * Holds the next game identifier
	 */
	private static long nextGameId = 1;
	
	/*
	 * Holds the next team identifier
	 */
	private static long nextTeamId = 1;
	
	/*
	 * Holds the next player identifier
	 */
	private static long nextPlayerId = 1;
	
	

	/*
	 * Private instance of the class only accessible within the class.
	 */
	private static GameService service;
	
	/*
	 * The private constructor will make sure that only an instance
	 * of the GameService object is created.
	 */
	private GameService() {
		
	}
	
	/*
	 * Ensures that only one instance of the object exists in memory.
	 * Returns the same instance of the class every time is called.
	 */
	public static GameService getInstance() {
		
		if (service == null) {
			
			// Creates a new instance of the class if no instance exists.
			service = new GameService();
			
			System.out.println("New Game Service Created.");
			
		} else {
	
			System.out.println("Game instance already exists...");
		}
		
		return service;
	}


	/**
	 * Construct a new game instance
	 * 
	 * @param name the unique name of the game
	 * @return the game instance (new or existing)
	 */
	public Game addGame(String name) {

		// a local game instance
		Game game = null;		

		// Use iterator to look for existing game with same name
		// if found, simply return the existing instance
		
		Iterator<Game> gameIterator = games.iterator();
		
		/*
		 * The Iterator pattern iterates over the list of games without
		 * exposing the underlying structure of the list. It makes the
		 * code easy to understand and improves the modularity of the project.
		 */
		
		while(gameIterator.hasNext()) {
			
			Game existingGame = gameIterator.next();
			
			if (existingGame.getName().equals(name)) {
				
				game = existingGame;
				break;
			}
		}

		// if not found, make a new game instance and add to list of games
		if (game == null) {
			game = new Game(nextGameId++, name);
			games.add(game);
		}

		// return the new/existing game instance to the caller
		return game;
	}

	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 */
	Game getGame(int index) {
		return games.get(index);
	}
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		// a local game instance
		Game game = null;

		// Use iterator to look for existing game with same id
		// if found, simply assign that instance to the local variable
		Iterator<Game> gameIterator = games.iterator();
		
		/*
		 * The Iterator pattern iterates over the list of games without
		 * exposing the underlying structure of the list. It makes the
		 * code easy to understand and improves the modularity of the project.
		 */
		
		while(gameIterator.hasNext()) {
			
			Game existingGame = gameIterator.next();
			
			if (existingGame.getId() == id) {
				game = existingGame;
				break;
			}
		}
		

		return game;
	}

	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;

		// Use iterator to look for existing game with same name
		// if found, simply assign that instance to the local variable
		
		Iterator<Game> gameIterator = games.iterator();
		
		/*
		 * The Iterator pattern iterates over the list of games without
		 * exposing the underlying structure of the list. It makes the
		 * code easy to understand and improves the modularity of the project.
		 */
		while(gameIterator.hasNext()) {
			
			Game existingGame = gameIterator.next();
			
			if (existingGame.getName().equals(name)) {
				
				game = existingGame;
				break;
			}
		}

		return game;
	}

	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}
	
	/**
	 * Returns the next player identifier
	 * 
	 * @return the next player identifier
	 */
	public long getNextPlayerId() {
		return nextPlayerId;
	}
	
	/**
	 * Returns the next team identifier
	 * 
	 * @return the next team identifier
	 */
	public long getNextTeamId() {
		return nextTeamId;
	}
}
