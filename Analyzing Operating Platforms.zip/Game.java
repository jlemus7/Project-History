package com.gamingroom;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

/**
 * A simple class to hold information about a game
 * 
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a game is
 * created.
 * </p>
 * 
 * @author coce@snhu.edu
 *
 */
public class Game extends Entity {
	long id;
	String name;
	
	/**
	 * A list of the active teams
	 */
	private static List<Team> teams = new ArrayList<Team>();
	
	/**
	 * Hide the default constructor to prevent creating empty instances.
	 */
    private Game() {
    	super(0, "");
	}
	

	/**
	 * Constructor with an identifier and name
	 */
	public Game(long id, String name) {
		this();
		//super(id, name);
		this.id = id;
		this.name = name;
	}
	
public Team addTeam(String name) {
		
		// local team instance
		Team team = null;
		
		Iterator<Team> teamIterator = teams.iterator();
		
		/*
		 * The Iterator pattern iterates over the list of teams without
		 * exposing the underlying structure of the list. It makes the
		 * code easy to understand and improves the modularity of the project.
		 */
		while(teamIterator.hasNext()) {
			
			// creates a local instance of the Iterator
			Team existingTeam = teamIterator.next();
			
			/*
			 * Loops through the entire list of teams, if the name already
			 * exists, returns existing instance of that team.
			 */
			if (existingTeam.getName().equals(name)) {
				team = existingTeam;
				break;
			}
			
		}
		
		// creates a new instance of the team and adds it to the list, if not found.
		if(team == null) {
			team = new Team(id++, name);
			teams.add(team);
			}
		
		// return the new/existing game instance to the caller
		return team;
	}

	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		
		return "Game [id=" + id + ", name=" + name + "]";
	}

}

