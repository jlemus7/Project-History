Country List Fetcher

Description:
The Country List app is a project that intents to read data stored on a JSON format from a URL. The app reads the complete data and stores each set in a JSONArray. The app uses a CountryMapper class to separately map data from the URL into a Country onject. Each country object is then stored into a List to be displayed to the user. The app does this in a background task to maintain the UI responsive for the user.
The app makes use of an adapter class that extracts each country and displays its details in a layout to the screen.

This app uses DiffUtil for optimization. Each class has a specific funtionality that improves the app's modular design and helps the implementation of programming best practices for readibility, debugging, and testing. The app also utilizes error handling techniques to validate data such as empty strings and exceptions.