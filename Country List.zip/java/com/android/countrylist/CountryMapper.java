package com.android.countrylist;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class CountryMapper {

    // maps data from a JSONArray into a Country
    public List<Country> mapJsonToCountryList(JSONArray jsonArray) throws JSONException {
        List<Country> countryList = new ArrayList<>();

        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject countryObject = jsonArray.getJSONObject(i);
            String capital = countryObject.getString("capital");
            String code = countryObject.getString("code");
            String name = countryObject.getString("name");
            String region = countryObject.getString("region");

            Country country = new Country(name, capital, region, code);
            countryList.add(country);
        }

        return countryList;
    }
}
