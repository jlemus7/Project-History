package com.android.countrylist;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public class CountryListFragment extends Fragment {

    CountryAdapter countryAdapter;
    private RecyclerView recyclerView;
    private List<Country> countryList = new ArrayList<>();
    private Parcelable recyclerViewState;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootview = inflater.inflate(R.layout.fragment_country_list, container, false);

        recyclerView = rootview.findViewById(R.id.country_list_view);

        countryAdapter = new CountryAdapter(countryList, getContext());
        recyclerView.setAdapter(countryAdapter);

        CountryParser countryParser = new CountryParser();
        countryParser.fetchCountryList(countryAdapter);

        if(savedInstanceState != null) {
            recyclerViewState = savedInstanceState.getParcelable("recycler_state");
        }

        return rootview;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if (recyclerViewState != null) {
            recyclerView.getLayoutManager().onRestoreInstanceState(recyclerViewState);
        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        recyclerViewState = recyclerView.getLayoutManager().onSaveInstanceState();
        outState.putParcelable("recycler_state", recyclerViewState);
    }

}