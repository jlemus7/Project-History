package com.android.countrylist;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class CountryParser {

    private final String urlString = "https://urldefense.com/v3/__https:/gist.githubusercontent.com/peymano-wmt/32dcb892b06648910ddd40406e37fdab/raw/db25946fd77c5873b0303b858e861ce724e0dcd0/countries.json__;!!IfjTnhH9!XjfVyw8Ew6XYYv8yP6_Nr8shFxIMqErBszmzUWT30TpEjjkmGIIHYhmanCMdtbzy3BVoVOLwOSDjMJpNLthl7psBxQRjvg$";
    private List<Country> countryList = new ArrayList<>();
    private  CountryAdapter countryAdapter;


    private class FetchDataAsyncTask extends AsyncTask<Void, Void, List<Country>> {

        // Extract data from a website and stores it into a list in a background task
        // to maintain the UI responsive for the user.
        @Override
        protected List<Country> doInBackground(Void... voids) {

            try {
                URL url = new URL(urlString);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();

                int responseCode = connection.getResponseCode();

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder response = new StringBuilder();

                    String line;

                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();

                    String responseData = response.toString();
                    JSONArray jsonArray = new JSONArray(responseData);

                    CountryMapper countryMapper = new CountryMapper();
                    countryList = countryMapper.mapJsonToCountryList(jsonArray);
                }

            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }

            return countryList;
        }

        @Override
        protected void onPostExecute(List<Country> countries) {
            countryList = countries;
            // Notify your UI components that the data is ready

            if (countryAdapter != null) {
                countryAdapter.updateList(countries);

            }
        }

    }


    public void fetchCountryList(CountryAdapter adapter) {
        countryAdapter = adapter;
        FetchDataAsyncTask task = new FetchDataAsyncTask();
        task.execute();
        adapter.updateList(countryList);
    }

}
