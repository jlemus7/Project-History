package com.android.countrylist;

import android.content.Context;
import android.content.res.Configuration;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class CountryAdapter extends RecyclerView.Adapter<CountryAdapter.ViewHolder> {

    private List<Country> countryList = new ArrayList<>();
    private Context context;

    public static class ViewHolder extends RecyclerView.ViewHolder {

        private final TextView countryName;
        private final TextView countryRegion;
        private final TextView countryCode;
        private final TextView countryCapital;

        // Initialize view resources
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            countryName = (TextView) itemView.findViewById(R.id.name_textview);
            countryRegion = (TextView) itemView.findViewById(R.id.region_textview);
            countryCode = (TextView) itemView.findViewById(R.id.code_textview);
            countryCapital = (TextView) itemView.findViewById(R.id.capital_textview);
            }
    }

    // Create new views (invoked by the layout manager)
    @NonNull
    @Override
    public CountryAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        // Create a new view, which defines the UI of the list item
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.country_details, parent, false);

        return new ViewHolder(view);
    }

    // set text of new view holder
    @Override
    public void onBindViewHolder(@NonNull CountryAdapter.ViewHolder holder, int position) {

        Country country = countryList.get(position);

        holder.countryName.setText(formatName(country.getCountryName()) + ",");
        holder.countryCapital.setText(formatCapital(country.getCountryCapital()));
        holder.countryRegion.setText(country.getCountryRegion());
        holder.countryCode.setText(country.getCountryCode());

    }

    @Override
    public int getItemCount() {
        return countryList.size();
    }

    public CountryAdapter(List<Country> countryList, Context context){
        this.countryList = countryList;
        this.context = context;
    }

    // Uses DiffUtil to optimize UI
    public void updateList(List<Country> newCountryList) {

        CountryDiffUtilCallback diffUtilCallback = new CountryDiffUtilCallback(countryList, newCountryList);
        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(diffUtilCallback);

        countryList.clear();
        this.countryList.addAll(newCountryList);

        diffResult.dispatchUpdatesTo(this);
    }

    // format country name based on its length.
    public String formatName(String name) {
        String newName = null;
        int maxSize = 0;

        if(isLandscape()) {
            maxSize = 45;
        } else {
            maxSize = 23;
        }

        if (name.length() > maxSize) {
                newName = name.substring(0, maxSize - 3) + "...";

                return  newName;
        }
        newName = name;
        return newName;
    }

    // update the string if the country has no capital
    public String formatCapital(String capital) {
        if (capital.isEmpty()) {

            // country has no capital
            return capital = "N/A";
        }
        return capital;
    }

    private boolean isLandscape() {
        int orientation = context.getResources().getConfiguration().orientation;

        return orientation == Configuration.ORIENTATION_LANDSCAPE;
    }


}
