package com.android.countrylist;

public class Country {

    private String countryCapital;
    private String countryCode;
    private String countryName;
    private String countryRegion;

    // Initializer
    public Country(String name, String capital, String region, String code) {
        countryName = name;
        countryCapital = capital;
        countryRegion = region;
        countryCode = code;
    }

    // Getters
    public String getCountryName() { return countryName; }
    public String getCountryCapital() { return countryCapital; }
    public String getCountryRegion() { return countryRegion; }
    public String getCountryCode() { return countryCode; }

}
