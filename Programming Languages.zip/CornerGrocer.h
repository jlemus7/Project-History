/*
* Name: Project 3
* Author: Jose Lemus
* Date: 02/19/2023
*/
#pragma once

#ifndef CORNERGROCER_H
#define CORNERGROCER_H

#include <iostream>
#include <vector>
#include "IoFormat.h"

// personalized namespace Corner Grocer Shopper.
namespace cgs {
	class CornerGrocer
	{
	public:
	
		void DisplayMenu();

		void DisplayTitle();

		vector<string> WordFrequency(vector<string> groceryItems, map<string, int>& itemFrequency);

		void DisplayItem(const string& item, map<string, int> groceryItems);

		void DisplaySortedValues(vector<pair<string, int>>& sortedItems, int displayType);

	};


}

#endif // !CORNERGROCER_H

