/*
* Name: Project 3
* Author: Jose Lemus
* Date: 02/19/2023
*/

#include <algorithm>
#include "CornerGrocer.h"
#include "IoFormat.h"

using namespace std;
using namespace iof;
using namespace cgs;

int main() {
	// Main() drives the program and implements the functions and objects from other files and classes.

	// Variable declaration.
	vector<string> groceryItems;
	vector<string> validItems;
	vector<pair<string, int>> sortedItems;
	map<string, int> itemFrequency;

	// Creates new objects of class
	IoFormat newFormat;
	CornerGrocer cornerGrocer;

	cornerGrocer.DisplayTitle();		// Displays title to screen.

	newFormat.ReadFile("CS210_Project_Three_Input_File.txt", groceryItems);			// Reads text file and stores content on vector.

	validItems = cornerGrocer.WordFrequency(groceryItems, itemFrequency);			// Counts word frequency and stores unique values on vector.

	newFormat.WriteToFile("frequency.dat", itemFrequency);							// Outputs map to a data file.

	SortVector(itemFrequency, sortedItems);			// Inserts values into a vector and sorts it.

	newFormat.MainDriver(validItems, sortedItems, itemFrequency);				// Manages the input and output of the program.

	return 0;
}