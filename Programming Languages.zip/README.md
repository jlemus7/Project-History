CS-210 Programming Languages

Description:
The project aimed to develop a program that counts the frequency of grocery items purchased at a store. The purpose was to analyze the purchase data and generate a sorted list of the most frequently bought items. The program was implemented using C++ and involved file reading and writing, as well as the utilization of containers like vectors and maps.

The program read a text file containing the items purchased in order and created a frequency map to track the occurrence of each item. The map was sorted in descending order based on the frequency of items, allowing the most purchased items to be displayed at the top of the list. The user interface provided options to continue displaying items or end the program, ensuring convenience and flexibility.

Identifying and handling repeated words in the input file was a challenge that required efficient checking and avoidance of duplicates. The std::count() function from the C++ standard library was used to address this issue. Designing the sorting mechanism was another challenge. Since maps are designed for fast access rather than sorting, the sorted map was inserted into a vector of pairs to enable convenient access while maintaining the sorted order.

Working with maps and understanding their capabilities for efficient data storage and retrieval was a valuable lesson from this project. File reading and writing techniques were learned and implemented, providing essential skills for handling external data. Exception handling was used to manage runtime errors, improving the overall robustness of the program.