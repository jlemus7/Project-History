/*
* Name: Project 3
* Author: Jose Lemus
* Date: 02/19/2023
*/
#pragma once
#ifndef IOFORMAT_H
#define IOFORMAT_H

#include <iostream>
#include <map>
#include <string>
#include <vector>

using namespace std;

// Personalized namespace Input/Output Format
namespace iof {
	class IoFormat
	{
	public:
		void GetInteger(const string& prompt, const int& minVal, const int& maxVal, int& value);

		void GetString(const string& prompt, string& input, vector<string>& validItems);

		void ReadFile(const string& fileName, vector<string>& items);

		void WriteToFile(const string& fileName, map<string, int> groceryItems);

		string ToTitle(const string input);

		void MainDriver(vector<string>& validItems, vector<pair<string, int >>& sortedItems, map<string, int>& itemFrequency);
	};

	bool SortByValue(const pair<string, int>& firstVal, const pair<string, int>& secondVal);

	void SortVector(map<string, int>& groceryItems, vector<pair<string, int>>& sortedItems);

	


}
#endif // !IOFORMAT_H

